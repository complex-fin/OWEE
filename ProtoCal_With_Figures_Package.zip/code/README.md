# Corrected ProtoCal reanalysis

This is a repaired local copy of the supplied code package. Original source
files in Downloads and the original manuscript were not overwritten.

## Run

Use Python 3.12 with the packages pinned in requirements.txt. From this folder:

```
python test_protocol.py
python run_corrected.py
```

No LLM API, network service, or GPU is used. Outputs are written to
`../results`. Completed experiment rows are checkpointed and skipped on
restart. To perform a completely fresh reproduction, use a fresh copy of the
code folder with no adjacent results folder. Do not mix results from edited
protocols in one results directory.

The supplied source-data files are under benchmark/data. Audit their licenses
and provenance before any external redistribution. This task's results do
not certify the original corpus labels or human annotation procedures.

## Changes that affect the scientific results

* The benchmark is described as the actual combined CMNEE–CMNIE holdout.
* Exact text duplicates are removed with training-first split precedence.
* The prototype loss has zero classification gradient for no-event documents.
* All score components are fitted without the final calibration half.
* The structure gap matches the median-hit scale and clipping actually used.
* The lower-half KS statistic evaluates the ECDF jump limits exactly.
* Known-type predictions and detection use the same selected branch.
* Grouping indexes documents consistently and retains every novel label.
* Incorrect types contribute both false positives and false negatives.
* Unmatched cluster predictions remain in the false-positive denominator.
* ARI/NMI/purity are restricted to singly novel detected documents; clustering
  itself still uses the full flagged pool.
* The contaminated CEEF experiment is not reused as held-out evidence.
* Schema-TFIDF and TriggerContext-LR are correctly named local comparators,
  not reproductions of generative Text2Event or GoLLIE.

## Outputs

* split_manifest.json: document IDs in every partition and removed duplicates.
* results.json: detection counts, intervals, calibration summaries, grouping,
  known-type classification, channel scores, and source-membership diagnostic.
* scores_*.npz: per-document scores and novelty ground truth.
* grouping_*.json: full gold novel sets, predictions, cluster assignments,
  Hungarian evaluation mappings, and complete micro-F1 confusion counts.

The ordinary document bootstrap does not account for story-level correlation
or alternative type partitions. Three training seeds are not three independent
datasets. The gate remains a heuristic; the fixed-score calibration theorem
does not certify the adaptive two-branch system.

## Manuscript figures

Run `python make_figures.py` to regenerate the five figures, then
`python build_manuscript.py` to build the illustrated Word manuscript.
The figures folder includes 300 dpi PNG, editable-text SVG, and vector PDF
versions, plus a source and hash manifest. Plots use saved corrected results;
this illustration revision does not rerun or alter the experiments.
