"""Run from this directory; writes only to ../results. CPU, no network."""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='2'
import sys,json,time,hashlib,platform,pickle
from pathlib import Path
import numpy as np
from sklearn.metrics import roc_auc_score,precision_recall_curve,average_precision_score
from threadpoolctl import threadpool_limits
threadpool_limits(2)
from corrected_protocol import *
from benchmark.bench import datasets as D
from benchmark.bench.models import LexiconEE,CentroidEE,EnergyEE,KNNOODEE,MahalanEE,GoLLIELite,Text2EventLite

OUT=Path(__file__).resolve().parent.parent/'results';OUT.mkdir(exist_ok=True)
train,valid,test,known,novel=D.build_owb()
train,valid,test,removed=deduplicate_splits(train,valid,test)
labels=np.array([bool({e['type'] for e in d['events']}-known) for d in test])
texts=[d['text'] for d in test]
perm=np.random.default_rng(123).permutation(len(valid));cal_idx=perm[len(perm)//2:];ref_idx=perm[:len(perm)//2]
ref=[valid[i] for i in ref_idx];caltexts=[valid[i]['text'] for i in cal_idx]
manifest={'n_train':len(train),'n_valid':len(valid),'n_test':len(test),'known':sorted(known),'novel':sorted(novel),
 'n_novel':int(labels.sum()),'removed_duplicate_ids':removed,
 'train_ids':[d['id'] for d in train],'reference_ids':[valid[i]['id'] for i in ref_idx],
 'calibration_ids':[valid[i]['id'] for i in cal_idx],'test_ids':[d['id'] for d in test]}
(OUT/'split_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')

def boot_auc(scores,other=None,b=500):
    rng=np.random.default_rng(0); vals=[]
    for _ in range(b):
        ix=rng.integers(0,len(labels),len(labels));y=labels[ix]
        if len(np.unique(y))<2:continue
        a=roc_auc_score(y,scores[ix])
        if other is not None:a-=roc_auc_score(y,other[ix])
        vals.append(a)
    return np.percentile(vals,[2.5,97.5]).tolist()

def metrics(scores,tau):
    flags=scores>tau;tp=int((flags&labels).sum());fp=int((flags&~labels).sum());fn=int((~flags&labels).sum())
    precision,recall,_=precision_recall_curve(labels,scores)
    return dict(auroc=float(roc_auc_score(labels,scores)),auroc_ci=boot_auc(scores),
      auprc=float(average_precision_score(labels,scores)),f1=2*tp/(2*tp+fp+fn) if tp else 0.,
      oracle_f1=float(np.max(2*precision*recall/(precision+recall+1e-30))),
      known_fpr=float(flags[~labels].mean()),flag_rate=float(flags.mean()),tp=tp,fp=fp,fn=fn,tau=float(tau))

def save(r):(OUT/'results.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
result={'protocol':'corrected combined-corpus benchmark; exact-text deduplication; fixed score before V_cal',
 'python':platform.python_version(),'numpy':np.__version__,'manifest':'split_manifest.json','protocal':[],'baselines':[]}
if (OUT/'results.json').exists():
    result=json.loads((OUT/'results.json').read_text(encoding='utf8'))
result['source_diagnostic']={'score':'1 for CMNEE, 0 for CMNIE; metadata diagnostic, not a deployed model',
 'auroc':float(roc_auc_score(labels,np.array([d['domain']=='cmnee' for d in test],float))),
 'counts':{domain:{'n':sum(d['domain']==domain for d in test),
 'novel':sum(d['domain']==domain and bool({e['type'] for e in d['events']}-known) for d in test)}
 for domain in ('cmnee','cmnie')}}
seeds=[42,7,2026]
for seed in seeds:
    if any(r['seed']==seed for r in result['protocal']):continue
    t=time.time();print('START ProtoCal',seed,flush=True)
    m=CorrectedProtoCal(seed);m.fit(train,valid);scores=np.asarray(m.novelty_scores(texts));r=metrics(scores,m.tau)
    R,G,rR,F=m.last_channels
    r.update(seed=seed,branch=m.branch,gate_stat=m.gate_stat,gate_null=m.gate_null,gstar=m.gstar,
       cal_flag_rate=m.cal_flag_rate,cal_bound=m.k/(m.n_cal+1),
       channel_auc={'R':float(roc_auc_score(labels,R)),'G':float(roc_auc_score(labels,G))},
       fusion_minus_R_ci=boot_auc(F,rR))
    r['grouping']=grouping(m,test,known,scores>m.tau,OUT/f'grouping_{seed}.json')
    np.savez_compressed(OUT/f'scores_protocal_{seed}.npz',scores=scores,R=R,G=G,labels=labels)
    # Known-type extraction is scored on all documents, preserving known
    # predictions even when a document receives a novel flag.
    pred=[set(x) for x in m.predict_batch(texts)]
    gold=[{e['type'] for e in d['events']}&known for d in test]
    r['known_extraction']=multilabel_counts(pred,gold)
    r['seconds']=time.time()-t;result['protocal'].append(r);save(result)
    print('DONE ProtoCal',seed,json.dumps(r),flush=True)

constructors={'Lexicon':lambda s:LexiconEE(),'Centroid':lambda s:CentroidEE(),
 'Softmax':lambda s:SoftmaxEE(),'Energy':lambda s:EnergyEE(),
 'ProtoCon':lambda s:ProtoConEE(seed=s),'KNN-OOD':lambda s:KNNOODEE(seed=s),
 'Mahalanobis':lambda s:MahalanEE(seed=s),'Schema-TFIDF':lambda s:GoLLIELite(),
 'TriggerContext-LR':lambda s:Text2EventLite()}
def score(m,tx):
    if hasattr(m,'novelty_scores'):return np.asarray(m.novelty_scores(tx),float)
    return np.array([m.novelty_score(t) for t in tx],float)

for name,make in constructors.items():
    ss=seeds if name in ('ProtoCon','KNN-OOD','Mahalanobis') else [42]
    for seed in ss:
        if any(r['method']==name and r['seed']==seed for r in result['baselines']):continue
        t=time.time();print('START',name,seed,flush=True)
        m=make(seed)
        # All fitting and legacy parameter tuning use training and V_ref
        # only; V_cal is passed only to the final threshold computation.
        cache=OUT/f'_prototype_cache_{seed}.pkl'
        if name in ('KNN-OOD','Mahalanobis') and cache.exists():
            # These supplied baselines train exactly the same projection as
            # ProtoCon. Reuse that deterministic fitted encoder; only their
            # distance estimators differ. No evaluation data enter fitting.
            with cache.open('rb') as f: proto=pickle.load(f)
            m.__dict__.update(proto.__dict__)
            if name=='KNN-OOD':
                m.k=5;m._Ztr=m._batch_encode([d['text'] for d in train])
            else:
                from sklearn.covariance import LedoitWolf
                Z=m._batch_encode_internal([d['text'] for d in train])
                tys=[{e['type'] for e in d['events']} for d in train]
                m._mu=np.stack([Z[[i for i,t in enumerate(tys) if u in t]].mean(axis=0) for u in m.types])
                m._P=LedoitWolf().fit(Z).precision_
        else:
            m.fit(train,ref)
        if name=='ProtoCon':
            with cache.open('wb') as f:pickle.dump(m,f)
        c=score(m,caltexts);tau,k=threshold(c)
        s=score(m,texts);r=metrics(s,tau);r.update(method=name,seed=seed)
        own=np.load(OUT/f'scores_protocal_{seed}.npz')['scores']
        r['protocal_minus_baseline_ci']=boot_auc(own,s)
        np.savez_compressed(OUT/f'scores_{name}_{seed}.npz',scores=s,cal_scores=c,labels=labels)
        r['seconds']=time.time()-t;result['baselines'].append(r);save(result)
        print('DONE',name,seed,json.dumps(r),flush=True)
print('COMPLETE',flush=True)
