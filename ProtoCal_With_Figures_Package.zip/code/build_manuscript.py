from pathlib import Path
import json, statistics, math, re, sys
from collections import defaultdict
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

BASE=Path(__file__).resolve().parent.parent
data=json.loads((BASE/'results/results.json').read_text(encoding='utf8'))
manifest=json.loads((BASE/'results/split_manifest.json').read_text(encoding='utf8'))
P=data['protocal'];B=data['baselines']
assert len(P)==3 and (len(B)==15 or '--preview' in sys.argv), (len(P),len(B))
def mean(key,rs=P):return statistics.mean(r[key] for r in rs)
def sd(key,rs=P):return statistics.stdev(r[key] for r in rs) if len(rs)>1 else 0.
def fmt(x):return f'{x:.3f}'
def band(key,rs=P):return f'{mean(key,rs):.3f} ± {sd(key,rs):.3f}' if len(rs)>1 else f'{mean(key,rs):.3f}'
def grouped(rows,key):
 d=defaultdict(list)
 for r in rows:d[r[key]].append(r)
 return d
baseline_groups=grouped(B,'method')
best=max(baseline_groups,key=lambda k:mean('auroc',baseline_groups[k]))
doc=Document(); sec=doc.sections[0]
sec.top_margin=sec.bottom_margin=Inches(.8)
sec.left_margin=sec.right_margin=Inches(.85)
sec.page_width=Inches(8.27);sec.page_height=Inches(11.69)
for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3','Caption']:
 s=doc.styles[name];s.font.name='Times New Roman';s.font.color.rgb=RGBColor(0,0,0)
 rf=s.element.get_or_add_rPr().find(qn('w:rFonts'))
 if rf is not None:
  for attr in ('asciiTheme','hAnsiTheme','eastAsiaTheme','cstheme','csTheme'):
   rf.attrib.pop(qn('w:'+attr),None)
  for attr in ('ascii','hAnsi','cs'):rf.set(qn('w:'+attr),'Times New Roman')
 s.paragraph_format.space_after=Pt(6)
doc.styles['Normal'].font.size=Pt(11)
doc.styles['Normal'].paragraph_format.line_spacing=1.05
doc.styles['Normal'].paragraph_format.space_after=Pt(5)
doc.styles['Title'].font.size=Pt(17)
doc.styles['Title'].paragraph_format.space_after=Pt(12)
doc.styles['Heading 1'].font.size=Pt(13)
doc.styles['Heading 2'].font.size=Pt(11.5)
doc.styles['Caption'].font.size=Pt(10)
for node in list(doc.styles.element.iter(qn('w:pBdr'))):node.getparent().remove(node)
for name in ['Heading 1','Heading 2','Heading 3']:
 doc.styles[name].paragraph_format.keep_with_next=True
md=[]
def title(t):doc.add_paragraph(t,'Title');md.append('# '+t+'\n')
def h(t,level=1):doc.add_paragraph(t,f'Heading {level}');md.append('#'*(level+1)+' '+t+'\n')
def p(t):
 para=doc.add_paragraph(t);para.paragraph_format.widow_control=True;md.append(t+'\n')
def eq(t):
 para=doc.add_paragraph();para.alignment=WD_ALIGN_PARAGRAPH.CENTER
 para.paragraph_format.space_before=Pt(4);para.paragraph_format.space_after=Pt(8)
 # Native OMML text retains editable mathematical content in Word.
 om=OxmlElement('m:oMath');mr=OxmlElement('m:r');mt=OxmlElement('m:t');mt.text=t;mr.append(mt);om.append(mr);para._p.append(om)
 md.append('    '+t+'\n')
def figure(name,caption):
 para=doc.add_paragraph();para.alignment=WD_ALIGN_PARAGRAPH.CENTER
 para.paragraph_format.keep_with_next=True
 para.paragraph_format.space_before=Pt(7);para.paragraph_format.space_after=Pt(3)
 run=para.add_run();run.add_picture(str(BASE/'figures'/f'{name}.png'),width=Inches(6.45))
 # Accessible text in the inline picture's OOXML.
 for node in run._r.iter(qn('wp:docPr')):node.set('descr',caption)
 cap=doc.add_paragraph(caption,'Caption');cap.paragraph_format.keep_together=True
 cap.paragraph_format.keep_with_next=False;cap.paragraph_format.space_after=Pt(9)
 md.append(f'![{caption}](figures/{name}.png)\n')
def table(caption,headers,rows,widths=None):
 cap=doc.add_paragraph(caption,'Caption');cap.paragraph_format.keep_with_next=True
 tab=doc.add_table(rows=1,cols=len(headers));tab.autofit=False
 if widths:
  for col,w in zip(tab.columns,widths):col.width=Inches(w)
  tblw=tab._tbl.tblPr.find(qn('w:tblW'))
  tblw.set(qn('w:type'),'dxa');tblw.set(qn('w:w'),str(round(sum(widths)*1440)))
 for c,t in zip(tab.rows[0].cells,headers):c.text=t
 for row in rows:
  for c,t in zip(tab.add_row().cells,row):c.text=str(t)
 for i,row in enumerate(tab.rows):
  # Avoid a row splitting across pages; allow natural row height.
  pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
  if i==0:pr.append(OxmlElement('w:tblHeader'))
  for c in row.cells:
   tcpr=c._tc.get_or_add_tcPr();b=OxmlElement('w:tcBorders')
   for edge in ['top','left','bottom','right']:
    e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');b.append(e)
   tcpr.append(b)
   sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'DCE6EF' if i==0 else ('F5F5F5' if i%2==0 else 'FFFFFF'));tcpr.append(sh)
   margins=OxmlElement('w:tcMar')
   for edge in ['top','left','bottom','right']:
    e=OxmlElement('w:'+edge);e.set(qn('w:w'),'65');e.set(qn('w:type'),'dxa');margins.append(e)
   tcpr.append(margins)
   for pp in c.paragraphs:
    pp.paragraph_format.space_after=Pt(2);pp.paragraph_format.line_spacing=1
    pp.paragraph_format.keep_with_next=(i<len(tab.rows)-1)
    for r in pp.runs:r.font.size=Pt(9);r.bold=(i==0)
  if widths:
   for c,w in zip(row.cells,widths):c.width=Inches(w)
 md.append(caption+'\n\n'+' | '.join(headers)+'\n'+' | '.join(['---']*len(headers))+'\n'+'\n'.join(' | '.join(map(str,r)) for r in rows)+'\n')

title('ProtoCal Sentence Level Novelty Detection with Known Class Calibration and Adaptive Gating for Open World Event Extraction')
h('Abstract')
p(f'Open-world event extraction requires a system to recognize familiar event types while identifying documents that may contain unseen types. Novel evidence can occupy only a small part of a document, making document-level novelty scores insensitive to local differences. We propose ProtoCal, a detector that combines the largest sentence-level prototype distance with an upper quantile of trigger-lexicon mismatch. Each channel is transformed against a fixed reference sample, and an independent known-class calibration sample determines an order-statistic threshold. Under exchangeability, this threshold bounds the marginal known-class flag probability; the guarantee applies to a fixed score and does not extend automatically to adaptive routing. A representation-based distribution-shift diagnostic selects between sentence-level and document-level scoring. We evaluate ProtoCal on a combined CMNEE–CMNIE benchmark with {manifest["n_test"]:,} test documents and {manifest["n_novel"]} novel documents. Across three training seeds, ProtoCal achieves AUROC {band("auroc")}, detection F1 {band("f1")}, and known-class false-positive rate {band("known_fpr")}. A retrospective source-membership diagnostic attains AUROC 0.730, revealing a substantial source confound. These results concern one fixed type holdout and do not establish a general advantage across sources. An evaluation that retains all novel labels separates detection from clustering and exposes the effect of severe type imbalance. The study provides an explicit calibration protocol and a reproducible evaluation of document triage, while identifying the additional evidence required for reliable novel-type discovery and cross-source deployment.')
p('Keywords: open-world event extraction; novelty detection; known-class calibration; sentence-level evidence; distribution shift; novel-type grouping.')

h('1 Introduction')
p('Event extraction systems usually operate with a fixed schema. Training annotations specify a set of event types, and the model learns to identify those types in new text. In a changing information environment, however, a document may describe an event outside the training schema. Assigning every document to an existing type can conceal these cases, whereas rejecting every unfamiliar formulation creates an unmanageable review queue. An open-world system therefore needs both a novelty detector and a clear account of what happens after a document is flagged.')
p('The relevant unit of novelty need not be the whole document. A news article may contain several familiar events and a brief passage describing an unseen type. Averaging its representations or lexical evidence can suppress that passage. This motivates sentence-level scoring, but it does not by itself prove that local scoring is better: maximum aggregation can be sensitive to document length and irrelevant sentences, and lexical mismatch can reflect missing vocabulary rather than a new event type. These alternatives must remain part of the interpretation.')
p('ProtoCal combines two signals. The representation channel asks whether any sentence lies far from all known-type prototypes. The lexical channel asks whether a substantial upper portion of sentence-level trigger gaps is large. Fixed empirical distribution functions place the two scores on a common reference scale. An independent sample of known documents then sets the flagging threshold. The resulting rule has a finite-sample marginal guarantee under exchangeability, without requiring labeled novel examples for threshold selection.')
p('Distribution shift creates a second problem. A sentence-level score calibrated on source data need not behave similarly on a different source. ProtoCal includes a lower-half distribution diagnostic based on reference-transformed representation scores. A large discrepancy routes the stream to a document-level score. This diagnostic is a heuristic for choosing granularity, not a general test that distinguishes covariate shift from concept shift. Its behavior depends on the reference sample, batch size, score discreteness, and composition of the incoming stream.')
p('The evaluation uses a combined CMNEE–CMNIE benchmark, with four event types withheld from training and validation. The corpus mixture, type imbalance, and weak document-level supervision limit the conclusions. In particular, source membership can correlate with novelty and must be examined as a diagnostic confound.')
p('The contribution is threefold. First, we specify sentence-level dual-channel scoring and calibration as separate operations, with explicit data roles and assumptions. Second, we separate document-level novelty detection from multilabel novel-type evaluation, retaining both incorrectly typed predictions and missed labels in the error counts. Third, we provide a reproducible evaluation that examines detection performance, channel contributions, type grouping, and source confounding. These contributions support an auditable triage pipeline; they do not establish automatic induction of a complete event schema.')

h('2 Related Work')
p('Recent surveys organize generative information extraction around the adaptation and generalization of pretrained and large language models (Xu et al., 2024; Zhang et al., 2025). They provide context for schema-conditioned extraction, while the present study examines a narrower prerequisite: deciding which documents require review for an unspecified event type. This distinction matters because successful extraction under a supplied schema and reliable rejection outside that schema require different evaluations.')
p('Structured prediction can also be expressed as translation between augmented natural languages, as in TANL (Paolini et al., 2021). At the argument level, PAIE uses prompts to model interactions among event roles and extract argument spans (Ma et al., 2022). These approaches clarify which structural outputs are absent from the present document-level evaluation; our novelty and grouping scores cannot substitute for their span- and role-level assessments.')
p('Instruction-based extraction broadens the range of schemas that a model can follow. InstructUIE studies multitask instruction tuning for unified extraction (Wang et al., 2023), and Instruct and Extract addresses on-demand extraction specified by users (Jiao et al., 2023). IEPile supplies a bilingual instruction corpus constructed from existing extraction datasets (Gui et al., 2024). UniversalNER uses targeted distillation for open named entity recognition (Zhou et al., 2024), an adjacent entity task rather than event-type discovery. For events, definition-following training explicitly targets detection of types described by unseen definitions (Cai et al., 2024). These systems are relevant future comparators, but the present local baselines do not reproduce them.')
p('Open-world learning also differs in when unfamiliar examples become available. ORCA learns from an unlabeled pool containing both seen and novel classes (Cao et al., 2022); ProtoCal fits its scoring components using known-only training and reference documents before grouping the flagged pool. A unified survey of anomaly, novelty, open-set, and OOD detection emphasizes the relationships among these settings (Salehi et al., 2022). We therefore describe the available supervision and data roles explicitly rather than using the task names interchangeably.')
p('Representation quality remains another independent design choice. SimCSE learns sentence embeddings through contrastive objectives (Gao et al., 2021). It motivates evaluating stronger sentence encoders, but ProtoCal here uses a document-supervised projection rather than a SimCSE encoder. The present results consequently do not establish how the scoring rule behaves with modern pretrained sentence representations.')
p('Evaluation tools and protocols are as consequential as model design. OmniEvent supports multiple event-understanding tasks and datasets in a common toolkit (Peng et al., 2023a). A related evaluation study identifies discrepancies in preprocessing, output spaces, and scoring that undermine direct comparisons between event extraction systems (Peng et al., 2023b). This motivates our explicit split audit, separation of document and structured outputs, and retention of false positives and all gold novel-label memberships in grouping evaluation.')
p('Event extraction has been developed through joint prediction and generation-based formulations. OneIE models interactions among entities, relations, and events through joint graph prediction (Lin et al., 2020). UIE unifies extraction targets through schema-conditioned text-to-structure generation (Lu et al., 2022), while DEGREE formulates low-resource event extraction as conditional generation with designed prompts (Hsu et al., 2022). These methods motivate the structured extraction component that a novelty detector would complement; their extraction capabilities do not, by themselves, establish calibrated detection of unspecified event types.')
p('Structured event extraction and novelty detection address different outputs. Text2Event generates event structures through controlled sequence-to-structure prediction (Lu et al., 2021). GoLLIE uses a language model trained to follow annotation guidelines for information extraction (Sainz et al., 2024). Their ability to extract specified types does not directly establish a calibrated rule for detecting unspecified types. Conversely, a document-level novelty detector does not establish trigger, argument, or evidence-span extraction quality. We therefore distinguish the present detection task from full structured extraction.')
p('Open relation and event type discovery is directly relevant. Li, Ji, and Han (2022) study type discovery through type abstraction. Such work should be considered when assessing novelty, naming, and grouping contributions. ProtoCal differs in the operational separation between known-only calibration and grouping of flagged documents. However, this study does not provide an empirical comparison with that method, so it makes no claim of superiority over established event-type discovery systems.')
p('OOD detection supplies useful scoring families. Maximum predictive confidence is a common starting point (Hendrycks and Gimpel, 2017); the local classifier here uses an adaptation based on independent known-type classifiers rather than a faithful reproduction of that baseline. Mahalanobis-based detection models distance from class-conditional representation distributions (Lee et al., 2018). Energy scores derive novelty information from classifier outputs (Liu et al., 2020), and nearest-neighbor methods use distances to training representations (Sun et al., 2022). The covariance baseline uses shrinkage estimation (Ledoit and Wolf, 2004). We evaluate local adaptations of these ideas on the benchmark features. They do not share every feature representation or training objective, so the experiment compares implemented pipelines rather than isolating novelty scores alone.')
p('Prototype learning provides a separate representation-level foundation. Prototypical networks classify by distances to class representatives in a learned space (Snell et al., 2017). ProtoCal borrows the class-representative principle, but its document-supervised projection and sentence-level scoring are not episodic few-shot training. Generalized category discovery studies an unlabeled pool containing familiar and unfamiliar categories (Vaze et al., 2022). That setting is relevant to grouping, but differs from the known-only fitting and calibration protocol studied here; no empirical superiority over generalized category discovery is established.')

p('Calibration is a protocol that can be applied to multiple detectors. A known-only order-statistic threshold is not specific to ProtoCal. It uses the exchangeability and sample-splitting logic underlying split-conformal calibration and related outlier procedures (Angelopoulos and Bates, 2023). Its validity rests on exchangeability of calibration and future known scores, together with independence between score fitting and threshold estimation. We apply the same threshold rule to eligible baselines, separating the quality of their scores from the choice of operating point. A favorable ranking score does not imply a useful calibrated operating point, and a valid flag probability bound does not imply high novelty recall.')
p('Two additional local comparators require precise names. The schema-matching comparator uses character TF-IDF similarity and trigger coverage; we call it Schema-TFIDF. The trigger-context implementation uses logistic regression on local trigger contexts; we call it TriggerContext-LR. Neither is a reproduction of a generative Text2Event model or an instruction-following GoLLIE model, and neither calls an LLM. Their results cannot support claims about the failure of those original systems.')

p('Clustering requires both an internal model-selection criterion and an external evaluation protocol. Silhouette measures cohesion relative to separation (Rousseeuw, 1987), whereas adjusted Rand agreement (Hubert and Arabie, 1985) and information-theoretic comparisons (Vinh et al., 2010) assess correspondence with a gold partition. These measures are not interchangeable with novel-label micro-F1. Retrospective assignment of clusters to types is an optimization problem, not evidence that a deployed system can name unseen types.')

h('3 Task and Data Roles')
p('Let Tₖ denote the known event types and Tᵤ the novel types, with Tₖ ∩ Tᵤ empty. A document d contains sentences s₁,…,sₘ and a possibly empty set of event labels Y(d). Detection predicts whether Y(d) intersects Tᵤ. Known-type prediction returns labels in Tₖ even when the document is flagged. Grouping partitions the flagged documents and is evaluated against novel labels only after the predictions have been fixed.')
p('The training split determines the vectorizers, projection, type prototypes, trigger lexicons, and classifier parameters. The known-only validation split is permuted with a fixed seed and divided into a reference half V_ref and a calibration half V_cal. V_ref supplies the empirical score transforms and may be used for known-type classifier thresholds and the document-head mixing parameter. V_cal supplies only the final novelty threshold and the reported gate null scale. No novel-labeled documents are used to fit these components.')
p('The test labels are used for evaluation, including retrospective cluster alignment. They are not available to the detector or cluster-count selection. Hungarian alignment gives an evaluation of possible cluster-to-type correspondence; it is not a deployable naming rule. In deployment, an analyst would inspect representative documents, name a proposed type, and decide whether to extend the schema. The cost and reliability of that process are not evaluated here.')

h('4 Method')
p('Figure 1 separates fitting, calibration, and test-time routing. The fixed-score calibration guarantee applies to the sentence branch under its stated assumptions; it does not certify the adaptive two-branch system.')
figure('fig1_architecture','Figure 1. ProtoCal architecture. A: Known-type training fits the representation, prototypes, lexicons, and prediction heads; separate reference and calibration splits determine score transforms and the threshold τ. B: Sentence-level representation and trigger-gap scores form a fixed-reference fused score. A batch diagnostic selects this score or a document-level score before thresholding. The matching known-type head preserves familiar-event predictions. Flagged documents are grouped for analyst review; the fixed-score guarantee applies to the sentence branch before adaptive routing.')
h('4.1 Learned Representation and Prototypes',2)
p('The implementation uses character unigram and bigram TF-IDF features followed by a learned linear projection and ReLU activation. A document representation is normalized for cosine comparison. Training uses document-level known-type labels, including multilabel documents; it does not use sentence-level event labels. Mini-batch class prototypes are the mean unnormalized projected representations of documents carrying each type. A temperature-scaled prototype classifier is optimized against the normalized multilabel target, with the prototypes treated as constants in each gradient step. The use of learned class representatives is related to prototype-based metric learning (Snell et al., 2017), although the training and inference units differ here.')
eq('z(x) = ReLU(xW);   pⱼ(x) = softmaxⱼ(cos(z(x), μⱼ)/T).     (1)')
p('For documents with at least one known label, the target assigns equal mass to their annotated types. Documents with no annotated events contribute no prototype-classification loss; the projection still receives its regularization update. This treatment avoids assigning an unexplained classification gradient to a zero target vector. The projection has 256 dimensions and is trained for 12 epochs with batch size 256, learning rate 0.5, temperature 0.07, and L2 coefficient 10⁻⁴. Final prototypes average the projected training documents carrying each type and are normalized for scoring. They are not restricted to pure-class documents.')
p('At inference, the same feature map and projection encode sentences. This transfers document-supervised features to a finer granularity; it should not be described as sentence-supervised training. The representation novelty score is the maximum cosine gap across the retained sentences:')
eq('R(d) = maxᵢ [1 − maxⱼ cos(z(sᵢ), μⱼ)].     (2)')
p('Sentence splitting follows a punctuation-based rule and normally discards segments shorter than six characters; if none remain, the full text is used. Maximum aggregation preserves a single large mismatch, but it can also amplify a noisy sentence. Its effect must therefore be established empirically rather than assumed to be uniformly robust.')
h('4.2 Trigger Mismatch Channel',2)
p('For each known type, the training annotations supply a trigger lexicon Wⱼ. The implemented hit count is the largest number of distinct lexicon entries matched by substring in a sentence for any one known type. It is not a sum over all type lexicons. The scale g* is the larger of one and the median training-sentence hit count. The normalized gap is clipped to the unit interval, and the document score uses a linearly interpolated 75th percentile:')
eq('g(s) = maxⱼ Σ[w ∈ Wⱼ] 1{w occurs in s};   g* = max(1, median_train g(s)).     (3)')
eq('G(d) = q₀.₇₅({clip(1 − g(sᵢ)/g*, 0, 1)}ᵢ).     (4)')
p('Taking the quantile over gaps, rather than over hits, is essential because the direction is reversed by subtraction. Nevertheless, the quarter-fraction intuition is only approximate. With finite documents and linear interpolation, the response depends on the sentence count and score values. A positive gap also need not cross the calibrated document threshold. The method therefore makes no guarantee that one novel sentence, or exactly one quarter novel sentences, will produce a flag.')
h('4.3 Fixed Reference Fusion and Calibration',2)
p('For each channel S in {R,G}, the fixed reference transform is the empirical fraction of V_ref scores at or below the new score. These transforms are monotone but discrete and can have large atoms. They should not be assumed to produce a continuous uniform distribution, especially for the trigger channel.')
eq('r̃ₛ(d) = |{v ∈ V_ref : S(v) ≤ S(d)}| / |V_ref|.     (5)')
eq('F_sent(d) = [r̃ᵣ(d) + r̃ɢ(d)] / 2.     (6)')
p('Equal weighting avoids fitting a fusion weight on novel examples. It does not guarantee that fusion matches or improves on the better channel. The calibration rule applies to the fused score after the score function and reference transforms have been fixed. With n calibration documents and nominal known-class flag probability γ, let k = floor((n+1)γ). The threshold is the kth largest calibration score, and a document is flagged only when its score is strictly larger than that threshold. If k is zero, the threshold is positive infinity and no documents are flagged.')
eq('τ = kth largest {F_sent(v) : v ∈ V_cal};   flag(d) = 1{F_sent(d) > τ}.     (7)')
p('The strict inequality is important when scores tie. The fraction flagged within V_cal need not equal γ. Likewise, γ is not an estimate of novel prevalence and is not a promise about precision, recall, or F1. This study uses γ = 0.15 for all eligible fixed-score methods.')
h('4.4 Adaptive Granularity and Its Scope',2)
p('ProtoCal computes a lower-half empirical distribution discrepancy from the representation-channel reference scores of a test batch B. The implemented statistic is the exact supremum over the interval [0,0.5], including both sides of empirical CDF jumps that lie inside that interval:')
eq('D_low(B) = sup₀≤u≤₀.₅ |F̂_B(u) − u|.     (8)')
p('Let D₀ be the same statistic on the reference-transformed representation scores of V_cal. The batch uses sentence-level fusion when D_low(B) ≤ max(0.15, 3D₀), and otherwise uses the document-level fusion branch. The floor and multiplier are retained as heuristic constants; they have not been independently validated across sources or batch sizes. A distribution difference in the lower half is not unique evidence of any one shift mechanism, and a finite reference sample makes uniformity only approximate even for continuous raw scores.')
p('The document branch combines SVD prototype distance with trigger-profile mismatch, using equal novelty weights. Its scores are normalized by within-batch ranks. The novelty threshold remains the source sentence-branch threshold, so this branch supplies a heuristic operating point without the calibration guarantee of Section 5. Detection and known-type extraction use the same selected branch. Known-type predictions are retained for flagged documents; flagging does not itself erase familiar events.')
p('The gate does not provide a calibration guarantee under arbitrary shift. Since routing depends on test data and on a statistic using V_cal, a guarantee for the complete adaptive system would require additional analysis. All calibration claims below concern the fixed sentence score before such routing.')
h('4.5 Novel Document Grouping',2)
p('For each flagged document, the grouping representation is the normalized mean of its three most unfamiliar retained sentence embeddings, or all available sentences when fewer than three remain. The entire flagged pool is clustered using average-linkage agglomerative clustering with cosine distance. The cluster count is selected from two through eight by cosine silhouette (Rousseeuw, 1987), using a fixed subsample of at most 400 flagged documents. Gold event labels do not enter this choice.')
p('In the implementation, embeddings wider than 128 dimensions are reduced to at most 64 SVD dimensions before clustering. Zero rows are replaced by deterministic small perturbations so that cosine distance is defined. These operations are specified because they affect the evaluated clustering; they are not presented as theoretically optimal choices.')

h('5 Calibration and Evaluation Guarantees')
h('5.1 Marginal Known Class Flag Probability',2)
p('Proposition 1 (order-statistic calibration; see Angelopoulos and Bates, 2023, for the related split-conformal framework). Fix a measurable score F before observing an independent calibration sample of n known documents. Suppose the future known document and the calibration documents have exchangeable scores, conditional on the fitted score function. For 1 ≤ k = floor((n+1)γ) ≤ n, let τ be the kth largest calibration score and flag strictly above τ. Then the marginal known-class flag probability is at most k/(n+1), which is at most γ.')
p('Proof. Add the future score to the n calibration scores and break ties uniformly at random. Exchangeability makes its rank uniform among the n+1 ranks. If the future score is strictly above the kth largest calibration score, it must occupy one of the k largest tie-broken ranks. The probability of that event is k/(n+1). Strict comparison can only remove flags caused by ties, so the inequality follows. Equality holds for continuous score distributions. If k = 0, the no-flag rule satisfies the bound trivially.')
p('This is a marginal statement over calibration and test draws, conditional on the independently fitted scoring rule. It does not state that every realized calibration split produces a population FPR below γ. It is also a generic order-statistic result, available to each baseline whose scalar score is fixed independently of V_cal.')
h('5.2 A Finite Batch Statement',2)
p('For iid calibration scores, the sharp Dvoretzky–Kiefer–Wolfowitz inequality (Massart, 1990) bounds the uniform difference between their empirical CDF and the population CDF by ε, with failure probability at most 2exp(−2nε²). On that event, the population probability of a strict exceedance of τ is at most γ+ε. This follows because at most k−1 calibration scores strictly exceed τ and (k−1)/n ≤ γ.')
p('For m iid future known documents independent of calibration, Hoeffding’s inequality (Hoeffding, 1963) then bounds a further deviation δ of their flag fraction. Combining the two events gives:')
eq('P(flag fraction ≥ γ + ε + δ) ≤ 2exp(−2nε²) + exp(−2mδ²).     (9)')
p('The Hoeffding term is conditional on calibration realizations satisfying the DKW event; it is not a conditional bound for every possible V_cal. The result concerns the fixed score F and a known population with the stated independence and distribution assumptions. Correlated streams, shifted known populations, and adaptive branch selection fall outside this statement.')
h('5.3 Multilabel Grouping and an End to End Bound',2)
p('Let P₁ be all flagged documents and P₂ the truly novel documents in that pool. Let L be the total number of gold novel label memberships in the test set. A document with two novel types contributes two memberships to L. After clustering, Hungarian assignment (Kuhn, 1955) maximizes the number of correctly assigned novel label memberships under a one-to-one cluster-to-type mapping. This uses gold labels only for retrospective evaluation.')
p('Every flag emits one cluster label. An unmatched cluster still emits an unmatched label, which counts as a false positive rather than disappearing from the prediction denominator. An incorrect type on a novel document contributes a false positive for the predicted type and a false negative for each missed gold type. Missed novel documents contribute all of their gold labels as false negatives. Consequently:')
eq('F1_end = 2TP / (|P₁| + L) ≤ 2|P₂| / (|P₁| + L).     (10)')
p('The numerator is bounded because a single predicted label can match at most one gold label per flagged document. Conditional novel-type micro-F1 uses only P₂ but retains every gold label there. The partition diagnostics are interpreted alongside the adjusted Rand and information-theoretic clustering literature (Hubert and Arabie, 1985; Vinh et al., 2010). ARI, NMI, and purity require a single gold partition, so they are reported only on detected documents carrying exactly one novel label, using their cluster assignments from the full flagged pool. These diagnostic populations are stated separately. High purity under severe type imbalance is not sufficient evidence of meaningful novel-type separation.')

h('6 Experimental Design')
h('6.1 Corpus Construction and Split Audit',2)
p(f'The benchmark combines CMNEE and CMNIE. Before deduplication it contains 14,987 training, 3,522 validation, and 6,000 test documents. Exact-text hashing retains the first occurrence in training, then validation, then test; later occurrences are removed. The resulting splits contain {manifest["n_train"]:,}, {manifest["n_valid"]:,}, and {manifest["n_test"]:,} documents. This removes duplicate training entries and exact train/test or validation/test text overlap. It does not establish absence of near duplicates or shared underlying source stories.')
p('The known types are Accident, Deploy, Exhibit, Experiment, and Manoeuvre. The novel types are Conflict, Indemnity, Injure, and Support. Documents carrying any withheld type are excluded from training and validation, including documents that also contain known events. No-event documents remain in the corpus. This construction is a fixed combined-corpus type holdout; the label and source distributions are not balanced.')
p('The original 6,000-document test split has 599 novel documents and 612 novel label memberships. Thirteen documents carry two novel types. Support is dominant: 506 documents carry Support alone, and additional documents combine it with another novel type. Such imbalance can produce high grouping purity even when a clustering fails to distinguish types. We therefore retain all gold labels for micro-F1 and interpret ARI and NMI alongside purity.')
table('Table 1 Audited benchmark and calibration roles',['Partition','Documents','Role'],[
 ['Training',manifest['n_train'],'Fit representations, prototypes, lexicons, classifiers'],
 ['Reference',len(manifest['reference_ids']),'Fit empirical channel transforms and known-head settings'],
 ['Calibration',len(manifest['calibration_ids']),'Set strict order-statistic novelty threshold'],
 ['Test',manifest['n_test'],'Evaluate the fixed type holdout'],
 ['Novel test documents',manifest['n_novel'],'Document-level novelty positives']], [1.25,.8,4.5])
p('The 24-document CEEF collection is excluded from evaluation because its known-type documents overlap with training and validation data. It therefore cannot provide independent cross-source evidence. A cross-source evaluation requires document-disjoint partitions with sufficient known-type support in each partition.')
h('6.2 Comparators and Reproducibility',2)
p('The comparisons include Lexicon, Centroid, Softmax, Energy, ProtoCon, KNN-OOD, Mahalanobis, Schema-TFIDF, and TriggerContext-LR. The comparators use local feature and scoring implementations. For prototype-based components, documents without event labels contribute only to regularization, as specified in Section 4.1. They are local baselines, not exhaustive reproductions of the original literature. Training and parameter selection receive only training and reference documents; the independent calibration half sets the final strict threshold.')
p('ProtoCal and the stochastic prototype, nearest-neighbor, and covariance baselines are evaluated with seeds 42, 7, and 2026. The remaining comparator implementations expose no training-seed parameter and are evaluated once; no across-seed standard deviation is reported for those fits. The reference/calibration permutation uses seed 123 for every method. Results are conditional on this one split and type holdout. Three training seeds quantify limited initialization variability; they do not provide evidence for robustness across type partitions, languages, or sources.')
p('Each method is assessed by AUROC, average precision, detection F1 at its calibrated threshold, known-class FPR, and total flag rate. Known-class FPR uses known documents only, whereas total flag rate uses the full test set. Reporting precision–recall alongside ROC is especially relevant under class imbalance (Davis and Goadrich, 2006); the two views answer different practical questions. Oracle F1 is computed only as a retrospective ranking diagnostic with tied scores handled at actual threshold boundaries. It is not an operational score. Known-type micro-F1 is evaluated separately, and the novel-type grouping metrics follow Section 5.3.')
p('AUROC intervals use 500 document bootstrap resamples with a fixed bootstrap seed, following the empirical-resampling principle of the bootstrap (Efron, 1979). Paired AUROC differences resample the same document indices for both methods. These intervals condition on a trained model and do not include uncertainty from source sampling, the corpus construction, or alternative type holdouts. Aggregate standard deviations describe the three training seeds and must not be confused with bootstrap confidence intervals.')

h('7 Results')
h('7.1 Detection and Calibrated Operating Points',2)
p(f'Across three training runs, ProtoCal obtains AUROC {band("auroc")}, average precision {band("auprc")}, and calibrated detection F1 {band("f1")}. Its mean known-class FPR is {mean("known_fpr"):.3f}, compared with the nominal bound γ = 0.15. These observed rates describe the evaluated split; the formal guarantee remains a marginal result under exchangeability. The mean total flag rate is {mean("flag_rate"):.3f}, which has a different denominator and interpretation.')
rows=[]
for name,rs in baseline_groups.items():rows.append([name,band('auroc',rs),band('auprc',rs),band('f1',rs),band('known_fpr',rs),len(rs)])
rows.append(['ProtoCal',band('auroc'),band('auprc'),band('f1'),band('known_fpr'),len(P)])
table('Table 2 Detection under the common calibration protocol',['Method','AUROC','AP','F1','Known FPR','Runs'],rows,[1.3,1.05,1.05,1.05,1.05,.5])
p(f'The highest mean AUROC among the implemented comparator pipelines is {best} ({mean("auroc",baseline_groups[best]):.3f}). This comparison must be interpreted together with the per-seed paired intervals in the released results. A numerical mean difference alone does not establish a stable improvement over alternative type holdouts or stronger pretrained baselines. The direction and statistical uncertainty of each comparison must be assessed from its paired interval.')
p('Figure 2 shows the operating trade-off across score thresholds. The pale ProtoCal curves display the other two training seeds; the comparison curves use seed 42. The curves concern the same pooled test split and do not establish performance under a new source distribution.')
figure('fig2_detection_curves','Figure 2. Detection curves on the test set. A: ROC curves; the diagonal is chance ranking. B: precision–recall curves; the horizontal line is novel-document prevalence. The solid ProtoCal curve and the named comparator curves use seed 42; pale blue curves use seeds 7 and 2026. Legend values are AUROC and average precision (AP), respectively.')
table('Table 3 ProtoCal seed-specific detection and calibration',['Seed','AUROC','95% bootstrap CI','F1','Known FPR','Branch'],[
 [r['seed'],fmt(r['auroc']),f"[{r['auroc_ci'][0]:.3f}, {r['auroc_ci'][1]:.3f}]",fmt(r['f1']),fmt(r['known_fpr']),r['branch']] for r in P],[.5,.7,1.65,.8,1.05,1.1])
h('7.2 Channel Evidence and Routing',2)
p('The channel comparison concerns the same trained representation and test documents. It separates the representation-only score from the lexical channel and their fixed-reference fusion. Differences are empirical observations on this benchmark, not consequences of rank normalization. In particular, a weak or saturated lexical channel can dilute a useful representation score, and sentence maxima can react to document length or noise.')
p('Figure 3 visualizes the paired channel results. The gain from fusion over the representation channel is modest; the trigger channel alone is weaker. Error bars summarize training-seed variability on this fixed test split, not uncertainty across corpora or type partitions.')
figure('fig3_channel_comparison','Figure 3. Representation, trigger-gap, and fused-score AUROC on the combined-corpus benchmark. Small points show the three training seeds; large points and error bars show their mean and sample standard deviation. The dashed line marks chance ranking. These error bars are not bootstrap confidence intervals.')
table('Table 4 Channels and the batch routing diagnostic',['Seed','R AUROC','G AUROC','Fused AUROC','D_low test','D_low cal'],[
 [r['seed'],fmt(r['channel_auc']['R']),fmt(r['channel_auc']['G']),fmt(r['auroc']),fmt(r['gate_stat']),fmt(r['gate_null'])] for r in P],[.5,1.05,1.05,1.2,1.,1.])
p('The reported routing choices only establish which branch was selected for these evaluated batches. They do not validate a general separation between within-source novel classes and cross-source shift. Independent batches of varied size, known-class composition, novel prevalence, and source are needed to evaluate routing error. The diagnostic should therefore be interpreted as a batch-routing heuristic whose generalization requires further evaluation.')
h('7.3 Grouping and Class Imbalance',2)
table('Table 5 Multilabel grouping on the full flagged pool',['Seed','Flags','Novel detected','Conditional F1','End F1','Upper bound'],[
 [r['seed'],r['grouping']['n_flagged'],r['grouping']['n_detected'],fmt(r['grouping']['conditional']['f1']),fmt(r['grouping']['e2e']['f1']),fmt(r['grouping']['bound'])] for r in P],[.5,.65,1.,1.2,1.,1.2])
table('Table 6 Single-novel-label clustering diagnostics',['Seed','Documents','Clusters','ARI','NMI','Purity'],[
 [r['seed'],r['grouping']['n_single_novel_detected'],r['grouping']['k'],fmt(r['grouping']['ari']),fmt(r['grouping']['nmi']),fmt(r['grouping']['purity'])] for r in P],[.5,1.,.8,1.,1.,1.25])
p('Conditional grouping F1 measures assignments only among detected novel documents and is not an end-to-end result. The latter counts every novel label missed by detection or type assignment and every incorrect predicted label. It must satisfy the bound based on the same predictions and gold label memberships. The complete per-document assignments and counts are retained so that this relationship can be checked directly.')
p('The results require caution about what high conditional scores mean. A mapping concentrated on Support can achieve a large conditional F1 or purity when that type dominates the detected population. ARI and NMI provide a complementary check of separation between types. A low value indicates that the grouping is not recovering much type structure, even if assigning the majority type is often correct. Accordingly, the results do not justify describing the clustering as successful novel-schema discovery or attributing the remaining bottleneck entirely to detection.')
p('Figure 4 keeps the detection and typing denominators separate. The end-to-end type score remains below its detection-derived bound, while the zero ARI and NMI values expose the limited type separation hidden by high purity.')
figure('fig4_detection_grouping','Figure 4. Detection and novel-type grouping. A: document detection F1, end-to-end multilabel type F1, and the bound 2|P₂|/(|P₁|+L), where L counts all gold novel labels. B: purity, ARI, and NMI on detected documents carrying one novel label; ARI and NMI coincide at zero in all three runs. Clustering itself uses the entire flagged pool.')
h('7.4 Known Types and Source Confounding',2)
p('Figure 5 shows both the source-specific novelty counts and the associated ranking diagnostic. The source-only score is included to expose a benchmark confound, not to claim an independently validated detector.')
figure('fig5_source_confound','Figure 5. Source confounding in the deduplicated test split. A: known and novel document counts by corpus (CMNEE: 548/3,000 novel; CMNIE: 51/2,998 novel). B: the retrospective source-membership AUROC alongside ProtoCal’s three seed scores and their mean ± sample SD. The source-only point has no independently estimated uncertainty and is not a deployed-model baseline.')
p(f'Known-type micro-F1 across all test documents is {statistics.mean(r["known_extraction"]["f1"] for r in P):.3f}. The detector retains known-type predictions for flagged documents. This result concerns document-type labels, not trigger spans or argument roles. Since the known-type head is a separate component, retaining its predictions is an architectural property; a zero-cost or no-degradation claim would additionally require a matched evaluation of the same head before and after routing.')
if 'source_diagnostic' in data:
 q=data['source_diagnostic']
 p(f'A metadata-only diagnostic assigning score one to CMNEE and zero to CMNIE yields AUROC {q["auroc"]:.3f}. This is not a deployable content-based novelty detector and its orientation is a retrospective diagnostic. It shows that corpus identity is associated with novelty in this split. A strong result on the pooled benchmark therefore cannot establish that the model specifically detects event-structure novelty rather than source-related differences. Source-stratified results and balanced constructions are needed to separate these effects.')

h('8 Limitations and Scope')
p('The first limitation is the benchmark. It contains two source corpora, a single fixed held-out type set, and a dominant novel type. Exact-text deduplication removes a clear form of overlap but does not replace a source-level provenance audit. The observations do not establish a general distinction between covariate and concept shift, nor do they demonstrate transfer to other event schemas or languages.')
p('Second, the supervision is weaker than the task name may imply. The representation learns from document labels, and the main evaluation predicts document types and novelty flags. Event triggers and arguments are not evaluated in these experiments. The study should therefore be read as an open-world triage component for event extraction, not a complete validated event extraction system.')
p('Third, the flag probability guarantee is conditional on substantive distributional assumptions. It does not protect against arbitrary changes in known-class vocabulary, correlated documents, adversarial content, or test-dependent routing. The document branch remains a heuristic under shift. More conservative joint calibration or a separately validated gate would be needed before claiming a guarantee for the complete adaptive pipeline.')
p('Fourth, the baselines use local feature pipelines. They provide interpretable comparisons but do not measure the capabilities of contemporary pretrained extraction models or LLMs. Direct comparisons with established event-type discovery systems, sentence-level versions of the distance baselines, and stronger representation encoders remain necessary before making broad superiority claims.')
p('Fifth, the clustering output requires human interpretation. Hungarian alignment is retrospective, high purity can result from imbalance, and one cluster label per document cannot represent every multilabel novel event configuration. An analyst study would be needed to measure naming reliability, duplicate types, review time, and the value of the proposed groups. These outcomes cannot be inferred from conditional F1 alone.')
p('Finally, the study does not establish a causal explanation for the effects of score aggregation. Coexisting known events are a plausible explanation for diluted document evidence, but document length, source membership, lexical coverage, and training behavior also change the scores. Controlled interventions on real documents, coupled with length-matched and source-stratified analyses, would be needed to isolate these explanations.')

h('9 Conclusion')
p('ProtoCal combines sentence-level prototype distance and trigger mismatch with fixed-reference score transforms and independent known-class calibration. The order-statistic rule gives a precise marginal guarantee for a fixed score under exchangeability, while the adaptive gate remains a separate heuristic. Evaluation on the combined-corpus benchmark supports useful document triage but also exposes limitations in type grouping, source confounding, and cross-source evidence. Reliable progress in open-world event extraction requires these distinctions to remain explicit: ranking, calibration, novel-type assignment, and structured extraction are related tasks, but performance on one does not establish success on the others.')

h('References')
reference_records=json.loads((BASE/'code/references.json').read_text(encoding='utf8'))
main_text=' '.join(md)
for record in reference_records:
 assert record['anchor'] in main_text, 'Uncited reference: '+record['key']
refs=[record['entry'] for record in reference_records]
for r in refs:
 p(r)
 ref_para=doc.paragraphs[-1]
 ref_para.paragraph_format.keep_together=True
 ref_para.paragraph_format.left_indent=Inches(.2)
 ref_para.paragraph_format.first_line_indent=Inches(-.2)
 ref_para.paragraph_format.line_spacing=1
 for run in ref_para.runs:run.font.size=Pt(10)

h('Appendix A Reproducibility Record')
doc.paragraphs[-1].paragraph_format.page_break_before=True
p('The accompanying code records exact split document IDs, removed duplicate IDs, package versions, per-seed detection scores, calibration scores for each baseline, novel label sets, cluster assignments, alignment mappings, and confusion counts. The threshold uses a strict comparison and an integer order statistic. The KS implementation evaluates ECDF jump limits rather than a coarse uniform grid. Known-type predictions and novelty flags use the same branch.')
p('All five figures are generated by make_figures.py from the ProtoCal method specification or the saved results. The package includes PNG, editable SVG, and vector PDF versions, together with a source manifest. ROC and average-precision values are checked against the stored metrics before plotting. The figures use the method and evaluation protocol described in this paper.')
p('The evaluation retains all predicted labels in false-positive accounting and all gold novel labels in recall computation. Score fitting is independent of the calibration half, and lexical-gap scaling and clipping follow Section 4.2. Documents with no annotated events contribute no prototype-classification gradient. These choices are recorded in the implementation and released predictions.')
p('The release includes no claim of an independent human annotation audit. Corpus licensing, annotation agreement, source provenance beyond exact-text checks, and the validity of the original corpus labels remain matters for the data providers and authors to document. The available files support reproducibility of the stated computational protocol, not certification of every underlying annotation.')

doc.core_properties.title='ProtoCal manuscript'
doc.core_properties.subject='Sentence-level novelty detection and known-class calibration'
doc.core_properties.author=''
doc.save(BASE/'ProtoCal_Revised_With_Figures.docx')
(BASE/'ProtoCal_Revised_With_Figures.md').write_text('\n'.join(md),encoding='utf8')
print('Saved',BASE/'ProtoCal_Revised_With_Figures.docx','words',len(' '.join(md).split()))
