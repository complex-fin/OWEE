"""特征工程: 共享 TF-IDF 向量化 + 触发词典 + 类型触发词画像 + 分词。"""
from __future__ import annotations

import re
from collections import defaultdict
from typing import Dict, List

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

# CJK 分词: 连续汉字单字 + 连续拉丁/数字
_TOKEN_RE = re.compile(r"[A-Za-z0-9]+(?:[.\-][A-Za-z0-9]+)*%?|[\u4e00-\u9fff]")


def tokenize(text: str) -> List[str]:
    return _TOKEN_RE.findall(text)


def doc_tokens_with_spans(text: str):
    """返回 [(token, (s, e))], 用于触发词归因。"""
    return [(m.group(0), (m.start(), m.end())) for m in _TOKEN_RE.finditer(text)]


def build_vectorizer(texts: List[str], ngram=(1, 2), max_features=60000, min_df=2):
    vec = TfidfVectorizer(analyzer="char", ngram_range=ngram, min_df=min_df,
                          max_features=max_features, sublinear_tf=True)
    vec.fit(texts)
    return vec


class TypeTriggerProfile:
    """每个事件类型的触发词字符画像(用于类型条件化触发词归因/证据块评分)。

    fit: 收集训练集中该类型全部触发词文本, 用字符 TF-IDF 建每类画像。
    score(token, type): 触发 token 与类型画像的余弦相似度。
    """
    def __init__(self, samples=None):
        self.vec = None
        self.profiles = {}          # type -> dense vector
        self.type_profiles = None   # doc-level type text profiles
        if samples:
            self.fit(samples)

    def fit(self, samples: List[Dict]):
        trig_by_type = defaultdict(list)
        for s in samples:
            for e in s["events"]:
                if e.get("trigger"):
                    trig_by_type[e["type"]].append(e["trigger"])
        self.vec = TfidfVectorizer(analyzer="char", ngram_range=(1, 2), min_df=1)
        all_trigs = [t for ts in trig_by_type.values() for t in ts]
        self.vec.fit(all_trigs + list(trig_by_type.keys()))
        M = self.vec.transform(list(all_trigs))
        # 每类画像 = 该类触发词的平均 TF-IDF 向量
        self.trig_texts = all_trigs
        self.trig_types = [t for t, ts in
                           [(ty, trig_by_type[ty]) for ty in trig_by_type] for _ in ts]
        # 重排保证顺序一致
        self.trig_types = []
        for ty, ts in trig_by_type.items():
            self.trig_types.extend([ty] * len(ts))
        X = M.toarray()
        for ty in trig_by_type:
            idx = [i for i, t in enumerate(self.trig_types) if t == ty]
            self.profiles[ty] = X[idx].mean(axis=0)

    def token_scores(self, text: str, types: List[str]):
        """对文本每个 token 计算其与各类型触发词画像的相似度(批量向量化)。"""
        toks = doc_tokens_with_spans(text)
        if not toks or not self.vec or not self.profiles:
            return []
        tlist = [t for t in (types or list(self.profiles)) if t in self.profiles]
        if not tlist:
            return []
        M = self.vec.transform([t for t, _ in toks]).toarray()          # (T, V)
        P = np.stack([self.profiles[t] for t in tlist])                  # (K, V)
        Mn = M / (np.linalg.norm(M, axis=1, keepdims=True) + 1e-12)
        Pn = P / (np.linalg.norm(P, axis=1, keepdims=True) + 1e-12)
        S = Mn @ Pn.T                                                    # (T, K)
        best_idx = S.argmax(axis=1)
        best_sc = S.max(axis=1)
        return [(toks[i][0], toks[i][1], tlist[best_idx[i]], float(best_sc[i]))
                for i in range(len(toks))]


def build_trigger_lexicon(samples: List[Dict], min_len=2):
    """类型 -> 触发词集合(词典基线用)。"""
    lex = defaultdict(set)
    for s in samples:
        for e in s["events"]:
            t = (e.get("trigger") or "").strip()
            if len(t) >= min_len:
                lex[e["type"]].add(t)
            elif t:  # 单字触发词也保留(军事域常见"试""撞"等)
                lex[e["type"]].add(t)
    return dict(lex)
