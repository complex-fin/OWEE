"""EEF-Bench: 事件抽取基准构建、模型训练与对比实验包。

数据集:
    B1 CMNEE    文档级军事新闻事件抽取(下载, ModelScope/mzzzhu/CMNEE, Apache-2.0)
    B2 CMNIE    句子级联合信息抽取(下载, ModelScope/NUDT-BDD/CMNIE)
    B3 OWB      开放世界协议(构造: CMNEE+CMNIE 并集, 稀有类型留出为新类)
    B4 CEEF     多模态证据评测集(构造: EEF 语料 + 扩展标注, 触发词/论元/证据块级金标)
"""
