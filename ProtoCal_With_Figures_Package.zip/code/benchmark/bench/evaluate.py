"""评测协议与指标。

E1 封闭集:  类型多标签 micro/macro-F1 (仅已知类文档)
E2 开放世界: 新类检测 AUROC / F1、新类聚类 ARI/NMI/纯度、开放世界整体 F1(OW-F1)
E3 证据:    触发词归因 span-F1、论元角色分类准确率、证据块检索 P@1/P@3 (分模态)
"""
from __future__ import annotations

from collections import defaultdict
from typing import Dict, List

import numpy as np
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import (adjusted_rand_score, normalized_mutual_info_score,
                             roc_auc_score)

from .features import TypeTriggerProfile, doc_tokens_with_spans


# ---------------- 基础: 类型多标签 F1 ----------------
def multilabel_f1(preds: List[set], golds: List[set]):
    tp = fp = fn = 0
    per_ty = defaultdict(lambda: [0, 0, 0])
    for p, g in zip(preds, golds):
        for t in p - g:
            fp += 1; per_ty[t][1] += 1
        for t in g - p:
            fn += 1; per_ty[t][2] += 1
        for t in g & p:
            tp += 1; per_ty[t][0] += 1
    micro_p = tp / (tp + fp) if tp + fp else 0.0
    micro_r = tp / (tp + fn) if tp + fn else 0.0
    micro = 2 * micro_p * micro_r / (micro_p + micro_r) if micro_p + micro_r else 0.0
    f1s = []
    for t, (a, b, c) in per_ty.items():
        pr = a / (a + b) if a + b else 0
        rc = a / (a + c) if a + c else 0
        f1s.append(2 * pr * rc / (pr + rc) if pr + rc else 0)
    macro = float(np.mean(f1s)) if f1s else 0.0
    return {"micro_f1": round(micro, 4), "macro_f1": round(macro, 4)}


# ---------------- E1: 封闭集评测 ----------------
def eval_closed_set(model, test, known: set):
    """仅在金标类型 ⊆ known 的文档上评测类型预测。"""
    sub = [s for s in test if {e["type"] for e in s["events"]} <= known]
    preds, golds = [], []
    for s in sub:
        r = model.predict(s["text"])
        preds.append(set(r["types"]))
        golds.append({e["type"] for e in s["events"]})
    return multilabel_f1(preds, golds)


# ---------------- E2: 开放世界评测 ----------------
def eval_open_world(model, test, known: set, profile: TypeTriggerProfile = None,
                    cluster_range=(2, 8)):
    """混合已知/新类测试集上的完整开放世界协议。

    步骤: (1) novelty 打分 → AUROC/最佳F1;
          (2) 判为新类的样本做凝聚聚类 → 聚类指标(仅金标为新类的子集);
          (3) OW-F1: 聚类经多数投票映射到类型后的全量类型 F1。
    """
    res = {}
    # --- (1) 新类检测 ---
    # 批量模式: 模型提供 novelty_scores(批量) 时避免逐条 SVD/投影开销
    nv_scores, is_novel = [], []
    if hasattr(model, "novelty_scores"):
        nv_scores = list(model.novelty_scores([s["text"] for s in test]))
    else:
        nv_scores = [model.novelty_score(s["text"]) for s in test]
    for s in test:
        is_novel.append(bool({e["type"] for e in s["events"]} - known))
    labels = np.array(is_novel)
    scores = np.array(nv_scores)
    if labels.sum() and (~labels).sum() and len(set(scores)) > 1:
        res["auroc"] = round(float(roc_auc_score(labels, scores)), 4)
        # 最佳 F1 扫描
        order = np.argsort(-scores)
        tp = fp = 0; fn = int(labels.sum()); best_f1 = 0.0
        for i in order:
            if labels[i]:
                tp += 1; fn -= 1
            else:
                fp += 1
            p = tp / (tp + fp) if tp + fp else 0
            r = tp / (tp + fn) if tp + fn else 0
            f1 = 2 * p * r / (p + r) if p + r else 0
            best_f1 = max(best_f1, f1)
        res["novel_f1_best"] = round(best_f1, 4)
    else:
        res["auroc"] = None; res["novel_f1_best"] = None
    # 校准阈值下的 F1(模型自身 ood_thr, 非oracle): 更严格诚实的操作点指标
    if getattr(model, "ood_thr", None) is not None and labels.sum():
        pred_flag = scores > model.ood_thr
        tp = int((pred_flag & (labels == 1)).sum())
        fp = int((pred_flag & (labels == 0)).sum())
        fn = int((~pred_flag & (labels == 1)).sum())
        p = tp / (tp + fp) if tp + fp else 0
        r_ = tp / (tp + fn) if tp + fn else 0
        res["novel_f1_cal"] = round(2 * p * r_ / (p + r_) if p + r_ else 0, 4)
        res["flag_rate"] = round(float(pred_flag.mean()), 4)

    # --- (2)(3) 聚类 + OW-F1 ---
    pred_rows = []
    flagged_idx = []
    # 批量预测: 模型提供 predict_batch 时避免逐条 SVD/投影
    batch_types = None
    if hasattr(model, "predict_batch"):
        batch_types = model.predict_batch([s["text"] for s in test])
    for i, s in enumerate(test):
        if batch_types is not None:
            types_i = set(batch_types[i])
            nov_flag = bool(scores[i] > getattr(model, "ood_thr", 0.0))
        else:
            r = model.predict(s["text"])
            types_i = set(r["types"])
            nov_flag = r.get("novel_flag", scores[i] > getattr(model, "ood_thr", 0.0))
        pred_rows.append({"pred_types": types_i, "novel_flag": bool(nov_flag)})
        if nov_flag:
            flagged_idx.append(i)

    if len(flagged_idx) >= 2:
        has_encode = hasattr(model, "encode")
        Z = None
        if hasattr(model, "novelty_embeddings"):
            # 新颖性聚焦嵌入(ours): 剥离文档中已知类部分后再聚类
            try:
                Z = model.novelty_embeddings([test[i]["text"] for i in flagged_idx])
                Z = np.nan_to_num(np.asarray(Z, dtype=float)) if Z is not None else None
            except Exception:
                Z = None
        if Z is None and has_encode:
            Z = np.stack([model.encode(s["text"]) for s in [test[i] for i in flagged_idx]])
            Z = np.nan_to_num(Z.astype(float))
            if Z.shape[1] > 256:
                from sklearn.decomposition import TruncatedSVD
                n_comp = min(64, Z.shape[0] - 1, Z.shape[1])
                if n_comp >= 2:
                    Z = TruncatedSVD(n_components=n_comp, random_state=0).fit_transform(Z)
        if Z is None and hasattr(model, "vec"):
            # 无 encode 的模型: TF-IDF 稀疏矩阵直接 SVD 降维(避免稠密化 OOM)
            from sklearn.decomposition import TruncatedSVD
            Zsp = model.vec.transform([test[i]["text"] for i in flagged_idx])
            n_comp = min(64, Zsp.shape[0] - 1, Zsp.shape[1])
            Z = TruncatedSVD(n_components=max(2, n_comp), random_state=0).fit_transform(Zsp)
        if Z is not None:
            # 余弦凝聚聚类不允许零向量: 对零范数行注入微噪声
            zero_rows = np.linalg.norm(Z, axis=1) == 0
            if zero_rows.any():
                Z[zero_rows] = 1e-6 * np.random.default_rng(0).standard_normal(
                    (int(zero_rows.sum()), Z.shape[1]))
        cl_labels = None
        if Z is not None:
            # 轮廓系数在子采样上计算(n>400 时), 加速簇数搜索
            best = None
            sil_idx = np.arange(len(Z)) if len(Z) <= 400 else \
                np.random.default_rng(0).choice(len(Z), 400, replace=False)
            for kc in range(cluster_range[0], cluster_range[1] + 1):
                if kc > len(flagged_idx):
                    break
                cl = AgglomerativeClustering(n_clusters=kc, metric="cosine", linkage="average").fit(Z)
                sil = _silhouette_cosine(Z[sil_idx], cl.labels_[sil_idx])
                if best is None or sil > best[0]:
                    best = (sil, cl.labels_, kc)
            _, cl_labels, k_used = best
            res["n_flagged"] = len(flagged_idx); res["k_selected"] = int(k_used)

            # 聚类质量(在金标为新类的被标记样本上)
            nov_true = [test[i] for i in flagged_idx]
            true_tys = [next(iter({e["type"] for e in s["events"]} - known), None) or
                        next(iter({e["type"] for e in s["events"]}), "NEG") for s in nov_true]
            res["ari"] = round(float(adjusted_rand_score(true_tys, cl_labels)), 4)
            res["nmi"] = round(float(normalized_mutual_info_score(true_tys, cl_labels)), 4)
            res["purity"] = round(_purity(true_tys, cl_labels), 4)

        # OW-F1: 有聚类时簇多数票映射到真实类型; 无聚类时全部用分类器类型
        cl2ty = {}
        if cl_labels is not None:
            for c in range(k_used):
                tys = [t for t, cc in zip(true_tys, cl_labels) if cc == c]
                if tys:
                    cl2ty[c] = max(set(tys), key=tys.count)
        preds, golds = [], []
        for i, s in enumerate(test):
            g = {e["type"] for e in s["events"]}
            if i in flagged_idx and cl_labels is not None:
                # 开放世界语义(v2 协议): 检测到新类不等于放弃已知抽取 ——
                # flagged 文档的预测 = 封闭头已知类型 ∪ 簇映射新类类型
                c = cl_labels[flagged_idx.index(i)]
                preds.append(pred_rows[i]["pred_types"] | ({cl2ty.get(c)} - {"UNKNOWN"}))
            else:
                preds.append(pred_rows[i]["pred_types"])
            golds.append(g)
        res["ow_f1"] = multilabel_f1(preds, golds)["micro_f1"]
        # 已知/新类分层
        known_docs = [i for i, s in enumerate(test) if not ({e["type"] for e in s["events"]} - known)]
        novel_docs = [i for i in range(len(test)) if i not in known_docs]
        if known_docs:
            res["known_f1"] = multilabel_f1([preds[i] for i in known_docs],
                                            [golds[i] for i in known_docs])["micro_f1"]
        if novel_docs:
            res["novel_group_f1"] = multilabel_f1([preds[i] for i in novel_docs],
                                                  [golds[i] for i in novel_docs])["micro_f1"]
        h = []
        if "known_f1" in res and "novel_group_f1" in res and res["known_f1"] and res["novel_group_f1"]:
            res["h_score"] = round(2 * res["known_f1"] * res["novel_group_f1"] /
                                   (res["known_f1"] + res["novel_group_f1"]), 4)
    return res


def _silhouette_cosine(X, labels):
    if len(set(labels)) < 2:
        return -1
    from sklearn.metrics import silhouette_score
    try:
        return float(silhouette_score(X, labels, metric="cosine"))
    except Exception:
        return -1


def _purity(true, pred):
    df = defaultdict(lambda: defaultdict(int))
    for t, p in zip(true, pred):
        df[p][t] += 1
    total = len(true)
    return sum(max(c.values()) for c in df.values()) / total if total else 0


# ---------------- E3: 证据评测 ----------------
def eval_trigger_attribution(model, test, profile: TypeTriggerProfile, span_thr=0.15):
    """类型条件化触发词归因: 对每个金标事件, 在预测类型∪金标类型条件下,
    取归因得分最高的 token, 并向相邻高分 token 扩展为 span(合并规则:
    相邻 token 且得分 ≥ 0.6×峰值)。指标: 严格 span F1 / 宽松重叠 F1 / 文本匹配 F1。"""
    strict_tp = strict_fp = strict_fn = 0
    loose_tp = loose_fp = loose_fn = 0
    text_tp = text_fp = text_fn = 0
    for s in test:
        for e in s["events"]:
            if not e.get("trig_off"):
                continue
            gs, ge = e["trig_off"]
            # 候选类型: 预测类型 ∪ 金标类型(衡量"若类型正确, 触发词是否定位准")
            r = model.predict(s["text"])
            cand_tys = set(r["types"]) | {e["type"]}
            toks = profile.token_scores(s["text"], list(cand_tys))
            best = max(toks, key=lambda x: x[3], default=None)
            if best and best[3] >= span_thr:
                # 从峰值 token 向两侧扩展相邻高分 token
                bi = toks.index(best)
                lo = hi = bi
                peak = best[3]
                while lo - 1 >= 0 and toks[lo - 1][3] >= 0.6 * peak and \
                        toks[lo - 1][1][1] == toks[lo][1][0]:
                    lo -= 1
                while hi + 1 < len(toks) and toks[hi + 1][3] >= 0.6 * peak and \
                        toks[hi][1][1] == toks[hi + 1][1][0]:
                    hi += 1
                ps, pe = toks[lo][1][0], toks[hi][1][1]
                if (ps, pe) == (gs, ge):
                    strict_tp += 1
                elif ps < ge and gs < pe:
                    loose_tp += 1; strict_fp += 1; strict_fn += 1
                else:
                    strict_fp += 1; loose_fp += 1; strict_fn += 1; loose_fn += 1
                # 文本匹配(位置无关)
                if s["text"][ps:pe] == e["trigger"]:
                    text_tp += 1
                else:
                    text_fp += 1
            else:
                strict_fn += 1; loose_fn += 1; text_fn += 1
    def f1(tp, fp, fn):
        p = tp / (tp + fp) if tp + fp else 0
        r = tp / (tp + fn) if tp + fn else 0
        return round(2 * p * r / (p + r), 4) if p + r else 0.0
    return {"trigger_strict_f1": f1(strict_tp, strict_fp, strict_fn),
            "trigger_overlap_f1": f1(loose_tp, loose_fp, loose_fn),
            "trigger_text_f1": f1(text_tp, text_fp, text_fn)}


def eval_argument_roles(train_args, test_args):
    """论元角色分类(金标论元 span 给定): 词典+最近原型基线 vs 训练分布。"""
    from collections import Counter
    most_common = Counter(r for _, r, _ in train_args).most_common(1)
    maj = most_common[0][0] if most_common else "None"
    # 字符 TF-IDF + 类中心
    from .features import build_vectorizer
    texts = [t for t, _, _ in train_args]
    vec = build_vectorizer(texts, min_df=1)
    X = vec.transform(texts).toarray()
    roles = sorted({r for _, r, _ in train_args})
    cent = {r: X[[i for i, rr in enumerate([x[1] for x in train_args]) if rr == r]].mean(axis=0)
            for r in roles}
    correct = total = 0
    per_role = defaultdict(lambda: [0, 0])
    for t, gold, _ctx in test_args:
        v = vec.transform([t]).toarray()[0]
        pred = max(roles, key=lambda r: float(v @ cent[r] / ((np.linalg.norm(v) * np.linalg.norm(cent[r])) + 1e-9)))
        total += 1
        correct += (pred == gold)
        per_role[gold][0] += (pred == gold); per_role[gold][1] += 1
    return {"arg_role_acc": round(correct / total, 4) if total else None,
            "majority_acc": round(sum(1 for _, g, _ in test_args if g == maj) / total, 4) if total else None,
            "per_role": {r: round(a / b, 3) for r, (a, b) in per_role.items()}}


def eval_evidence_retrieval(test, model, profile: TypeTriggerProfile, systems=("random", "lexical", "proto")):
    """证据块检索: 对每个金标事件排序文档内 chunk, P@1 / P@3(命中 gold_chunks)。"""
    res = {s: {"hits1": 0, "hits3": 0, "n": 0} for s in systems}
    mod_stats = defaultdict(lambda: {"hits1": 0, "n": 0})
    rng = np.random.default_rng(0)
    for s in test:
        if not s.get("chunks"):
            continue
        for e in s["events"]:
            if not e.get("gold_chunks"):
                continue
            gold = set(e["gold_chunks"])
            r = model.predict(s["text"])
            pred_tys = set(r["types"]) | {e["type"]}
            trig = e.get("trigger") or ""
            chunk_feats = [c["text"] for c in s["chunks"]]
            for sysname in systems:
                if sysname == "random":
                    order = list(rng.permutation(len(s["chunks"])))
                elif sysname == "lexical":
                    # 词面重叠: chunk 与 (触发词+类型关键词) 的字符重合
                    kw = set(trig) | set(e["type"].replace(".", "").replace("_", ""))
                    order = sorted(range(len(s["chunks"])),
                                   key=lambda i: -len(kw & set(chunk_feats[i])))
                else:  # proto: 模型编码相似度 + 触发词画像混合
                    if hasattr(model, "encode"):
                        zv = model.encode(" ".join(chunk_feats))
                        zn = zv / (np.linalg.norm(zv) + 1e-9)
                        idxs = [model.types.index(t) for t in pred_tys if t in model.types]
                        if idxs:
                            sims = model.mu_n[idxs] @ zn
                        else:
                            sims = np.zeros(1)
                        base = float(np.max(sims)) if len(sims) else 0.0
                    else:
                        base = max(r["scores"].get(t, 0) for t in pred_tys) if r["scores"] else 0
                    tsc = profile.token_scores(s["text"], list(pred_tys))
                    tmax = max((x[3] for x in tsc), default=0.0)
                    order = sorted(range(len(s["chunks"])),
                                   key=lambda i: -(0.6 * base + 0.4 * tmax * _trig_in_chunk(trig, chunk_feats[i])))
                top1 = order[:1]
                top3 = order[:3]
                res[sysname]["n"] += 1
                res[sysname]["hits1"] += int(any(i in gold for i in top1))
                res[sysname]["hits3"] += int(any(i in gold for i in top3))
                # 分模态(按 lexical 系统的 top1 统计独立记录 proto 的)
                if sysname == "proto":
                    for i in top1:
                        if i in gold:
                            m = s["chunks"][i]["modality"]
                            mod_stats[m]["hits1"] += 1
                            break
    out = {}
    for sysname, d in res.items():
        if d["n"]:
            out[sysname] = {"P@1": round(d["hits1"] / d["n"], 4), "P@3": round(d["hits3"] / d["n"], 4), "n": d["n"]}
    out["modality_breakdown_top1"] = {m: round(v["hits1"] / v["n"], 3) for m, v in mod_stats.items() if v["n"]}
    return out


def _trig_in_chunk(trig, chunk_text):
    return 1.0 if trig and trig in chunk_text else 0.0
