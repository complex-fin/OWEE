"""事件检测模型: 3 个基线 + 原型对比模型(ProtoCon, ours)。

统一接口:
    fit(train, valid)          训练(含验证集自动定阈值)
    predict_scores(text) -> {type: score}      类型多标签得分(越高越可能)
    predict(text, thr) -> dict(types=[...], trigger=(s,e,tok) | None, novelty=score)
    novelty_score(text) -> float               新类得分(高=可能是新类)

说明:
    - Lexicon: 词典匹配基线(EEF 离线词法后端的基准化实现)
    - Centroid: TF-IDF 类中心余弦(EEF 当前新颖性检测头的基准化实现)
    - Softmax: one-vs-rest 逻辑回归 + max-softmax OOD(经典判别基线)
    - ProtoCon: TF-IDF→线性投影编码器 + 原型对比损失(ours, 可增量更新)
"""
from __future__ import annotations

import numpy as np
from collections import defaultdict
from sklearn.linear_model import LogisticRegression
from sklearn.metrics.pairwise import cosine_similarity

from .features import build_trigger_lexicon, build_vectorizer, doc_tokens_with_spans, TypeTriggerProfile


def _auto_threshold(scores_by_class: dict, valid, key="f1"):
    """在验证集上为每类扫描阈值, 最大化该类 F1。"""
    thrs = {}
    for ty, (pos, neg) in scores_by_class.items():
        best, best_f1 = 0.5, -1
        cands = sorted(set(pos + neg)) + [1.0]
        for t in cands:
            tp = sum(1 for x in pos if x >= t)
            fp = sum(1 for x in neg if x >= t)
            fn = len(pos) - tp
            p = tp / (tp + fp) if tp + fp else 0
            r = tp / (tp + fn) if tp + fn else 0
            f1 = 2 * p * r / (p + r) if p + r else 0
            if f1 > best_f1:
                best_f1, best = f1, t
        thrs[ty] = best
    return thrs


class BaseEE:
    name = "base"
    def fit(self, train, valid=None):
        raise NotImplementedError
    def predict_scores(self, text):
        raise NotImplementedError
    def novelty_score(self, text):
        return -max(self.predict_scores(text).values(), default=0.0)
    def predict(self, text, thrs=None):
        sc = self.predict_scores(text)
        thrs = thrs or getattr(self, "thrs", {})
        types = [t for t, s in sc.items() if s >= thrs.get(t, 0.5)]
        return {"types": types, "scores": sc, "novelty": -max(sc.values(), default=0.0)}


# ================= M1 词典基线 =================
class LexiconEE(BaseEE):
    name = "Lexicon"
    def fit(self, train, valid=None):
        self.lex = build_trigger_lexicon(train)
        self.types = sorted(self.lex)
        self.thrs = {t: 1 for t in self.types}
        self.ood_thr = 0.5          # novelty ∈ {0,1}: 无命中即判新类
        return self
    def predict_scores(self, text):
        sc = {t: 0.0 for t in self.types}
        for t, ws in self.lex.items():
            sc[t] = sum(1 for w in ws if w in text)
        mx = max(sc.values()) if sc else 1
        return {t: s / mx if mx else 0.0 for t, s in sc.items()} if mx else sc
    def predict(self, text, thrs=None):
        sc = self.predict_scores(text)
        types = [t for t, s in sc.items() if s >= 1]      # 至少 1 次触发词命中
        trig = None
        for t in types:
            for w in self.lex[t]:
                i = text.find(w)
                if i >= 0:
                    trig = (i, i + len(w), w)
                    break
            if trig:
                break
        matched = any(sc.values())
        return {"types": types, "scores": sc, "trigger": trig, "novelty": 0.0 if matched else 1.0}


# ================= M2 类中心余弦 =================
class CentroidEE(BaseEE):
    name = "Centroid"
    def fit(self, train, valid=None):
        texts = [s["text"] for s in train]
        self.vec = build_vectorizer(texts)
        X = self.vec.transform(texts)          # 保持稀疏, 防全量 OOM
        self.types = sorted({e["type"] for s in train for e in s["events"]})
        ty_idx = defaultdict(list)
        for i, s in enumerate(train):
            for e in s["events"]:
                ty_idx[e["type"]].append(i)
        self.cent = {ty: np.asarray(X[idx].mean(axis=0)).ravel() for ty, idx in ty_idx.items()}
        for ty in self.types:
            self.cent.setdefault(ty, np.zeros(X.shape[1]))
        # 验证集自动定类阈值
        if valid:
            sbc = {t: ([], []) for t in self.types}
            for s in valid:
                sc = self.predict_scores(s["text"])
                gt = {e["type"] for e in s["events"]}
                for t, v in sc.items():
                    sbc[t][0 if t in gt else 1].append(v)
            self.thrs = _auto_threshold(sbc, valid)
            nv = [self.novelty_score(s["text"]) for s in valid]
            self.ood_thr = float(np.quantile(nv, 0.9))
        else:
            self.thrs = {t: 0.15 for t in self.types}
            self.ood_thr = 1.0
        return self
    def predict_scores(self, text):
        if getattr(self, "_Cn", None) is None:
            Cm = np.stack([np.asarray(self.cent[t]).ravel() for t in self.types])
            cn = np.linalg.norm(Cm, axis=1)
            self._Cn = (Cm, cn)
        Cm, cn = self._Cn
        v = self.vec.transform([text]).toarray()[0]
        nv = np.linalg.norm(v)
        sims = Cm @ v / (cn * nv + 1e-12)
        return {t: float(s) for t, s in zip(self.types, sims)}
    def predict(self, text, thrs=None):
        r = super().predict(text, thrs or self.thrs)
        r["trigger"] = None
        return r
    def novelty_score(self, text):
        return -max(self.predict_scores(text).values(), default=0.0)


# ================= M3 Softmax(one-vs-rest + MSP OOD) =================
class SoftmaxEE(BaseEE):
    name = "Softmax"
    def fit(self, train, valid=None):
        texts = [s["text"] for s in train]
        self.vec = build_vectorizer(texts)
        X = self.vec.transform(texts)
        self.types = sorted({e["type"] for s in train for e in s["events"]})
        Y = np.zeros((len(train), len(self.types)))
        for i, s in enumerate(train):
            for e in s["events"]:
                j = self.types.index(e["type"])
                Y[i, j] = 1
        self.clfs = {}
        for j, ty in enumerate(self.types):
            if Y[:, j].sum() < 2:
                continue
            clf = LogisticRegression(C=4.0, max_iter=1000, solver="liblinear")
            clf.fit(X, Y[:, j])
            self.clfs[ty] = clf
        self._clf_types = sorted(self.clfs)   # 训练样本≥2 的类型子集
        if valid:
            sbc = {t: ([], []) for t in self.types}
            for s in valid:
                sc = self.predict_scores(s["text"])
                gt = {e["type"] for e in s["events"]}
                for t, v in sc.items():
                    sbc[t][0 if t in gt else 1].append(v)
            self.thrs = _auto_threshold(sbc, valid)
            nv = [self.novelty_score(s["text"]) for s in valid]
            self.ood_thr = float(np.quantile(nv, 0.9))
        else:
            self.thrs = {t: 0.5 for t in self.types}
            self.ood_thr = 1.0
        return self
    def _coef_matrix(self):
        """缓存 (W, b): 每类逻辑回归系数, 稀疏矩阵乘代替逐 clf predict_proba 调用。"""
        key = (id(self.clfs), tuple(self._clf_types))
        if getattr(self, "_Wb", None) is None or self._Wb[2] != key:
            import scipy.sparse as sp
            tl = self._clf_types
            W = np.stack([self.clfs[t].coef_[0] for t in tl]) if tl else np.zeros((0, self.vec.transform([""]).shape[1]))
            b = np.array([self.clfs[t].intercept_[0] for t in tl]) if tl else np.zeros(0)
            self._Wb = (sp.csr_matrix(W), b, key)
        return self._Wb[0], self._Wb[1]
    def predict_scores(self, text):
        x = self.vec.transform([text])
        W, b = self._coef_matrix()
        z = (W @ x.T).toarray().ravel() + b
        out = {ty: float(v) for ty, v in zip(self._clf_types, 1.0 / (1.0 + np.exp(-z)))}
        for ty in self.types:
            out.setdefault(ty, 0.0)   # 未训练类型得 0 分
        return out
    def predict(self, text, thrs=None):
        r = super().predict(text, thrs or self.thrs)
        r["trigger"] = None
        return r
    def novelty_score(self, text):
        return 1.0 - max(self.predict_scores(text).values(), default=0.0)


# ================= M4 ProtoCon (ours) =================
class ProtoConEE(BaseEE):
    """原型对比事件检测器:
    编码器 z = ReLU(W·tfidf) (线性投影, CPU 秒级训练);
    原型 μ_c = 类内均值; 得分 = exp(cos(z, μ_c)/T) 归一;
    损失 = 多标签原型 softmax + 类间对比(推远不同类原型);
    OOD = -max cos(z, μ_c) (温度无关, 阈值在验证集上取 FPR=0.1 或最佳 F1);
    支持增量: 新类样本到达后 add_class() 重训仅 W 与新原型。
    """
    name = "ProtoCon"
    def __init__(self, dim=256, lr=0.5, temp=0.07, epochs=12, seed=42, l2=1e-4, max_features=20000):
        self.dim, self.lr, self.temp, self.epochs, self.seed, self.l2 = dim, lr, temp, epochs, seed, l2
        self.max_features = max_features

    def fit(self, train, valid=None):
        rng = np.random.default_rng(self.seed)
        texts = [s["text"] for s in train]
        self.vec = build_vectorizer(texts, max_features=self.max_features)
        Xs = self.vec.transform(texts)
        n, d = Xs.shape
        self.types = sorted({e["type"] for s in train for e in s["events"]})
        k = len(self.types)
        Y = np.zeros((n, k))
        for i, s in enumerate(train):
            for e in s["events"]:
                Y[i, self.types.index(e["type"])] = 1
        self.W = rng.normal(0, (2.0 / d) ** 0.5, (d, self.dim)).astype(np.float32)
        # mini-batch SGD; 原型 per-batch 由标签聚合(stop-gradient), 梯度全向量化
        # 注意: X 保持稀疏, 仅按批 dense 化, 避免全量 dense 矩阵内存爆炸
        bs = 256
        for ep in range(self.epochs):
            idx = rng.permutation(n)
            for b0 in range(0, n, bs):
                bi = idx[b0:b0 + bs]
                Xb = np.asarray(Xs[bi].todense(), dtype=np.float32)
                Yb = Y[bi]
                Z = np.maximum(Xb @ self.W, 0)
                znrm = np.linalg.norm(Z, axis=1, keepdims=True) + 1e-8
                zn = Z / znrm
                mu = self._protos(Z, Yb)
                mun = mu / (np.linalg.norm(mu, axis=1, keepdims=True) + 1e-8)
                cz = zn @ mun.T                                    # (b,k) 余弦
                P = _softmax(cz / self.temp)
                m = Yb.sum(axis=1, keepdims=True) + 1e-8
                M = Yb / m
                # Documents without known events have no positive prototype
                # target. Their prototype cross-entropy is zero, rather than
                # the erroneous P/temp gradient in the supplied code.
                A = (P - M) * (Yb.sum(axis=1, keepdims=True) > 0) / self.temp
                # dcos(z, mu_j)/dz = (mu_n_j - cz_ij z_n_i)/|z_i|
                dZ = (A @ mun - np.einsum("bk,bk->b", A, cz)[:, None] * zn) / znrm
                dZ *= (Xb @ self.W > 0)                            # ReLU 梯度
                gW = Xb.T @ dZ / Xb.shape[0] + self.l2 * self.W
                self.W -= self.lr * gW
        # 最终原型(全量, 分批投影)
        Zs = []
        for b0 in range(0, n, 4096):
            Zs.append(np.maximum(np.asarray(Xs[b0:b0 + 4096].todense(), np.float32) @ self.W, 0))
        Z = np.vstack(Zs)
        self.mu = self._protos(Z, Y)
        self.mu_n = self.mu / (np.linalg.norm(self.mu, axis=1, keepdims=True) + 1e-8)
        # OOD 阈值: 验证集已知样本 novelty 的 90 分位(即 FPR≈10%)
        if valid:
            nv = [self.novelty_score(s["text"]) for s in valid]
            self.ood_thr = float(np.quantile(nv, 0.9))
            # 类阈值
            sbc = {t: ([], []) for t in self.types}
            for s in valid:
                sc = self.predict_scores(s["text"])
                gt = {e["type"] for e in s["events"]}
                for t, v in sc.items():
                    sbc[t][0 if t in gt else 1].append(v)
            self.thrs = _auto_threshold(sbc, valid)
        else:
            self.ood_thr, self.thrs = 0.5, {t: 0.3 for t in self.types}
        return self

    @staticmethod
    def _protos(Z, Y):
        k = Y.shape[1]
        mu = np.zeros((k, Z.shape[1]), dtype=np.float32)
        for j in range(k):
            idx = Y[:, j] > 0
            mu[j] = Z[idx].mean(axis=0) if idx.any() else 0.0
        return mu

    def encode(self, text):
        # 单条缓存: predict/novelty/is_novel 对同一文本连续调用时避免重复投影
        if getattr(self, "_enc_memo", None) is not None and self._enc_memo[0] == text:
            return self._enc_memo[1]
        x = self.vec.transform([text]).toarray()[0].astype(np.float32)
        z = np.maximum(x @ self.W, 0)
        self._enc_memo = (text, z)
        return z

    def predict_scores(self, text):
        z = self.encode(text)
        zn = z / (np.linalg.norm(z) + 1e-8)
        cos = self.mu_n @ zn
        return {t: float(np.exp(cos[i] / self.temp)) for i, t in enumerate(self.types)}

    def novelty_score(self, text):
        z = self.encode(text)
        zn = z / (np.linalg.norm(z) + 1e-8)
        return float(-np.max(self.mu_n @ zn))

    def is_novel(self, text):
        return self.novelty_score(text) > self.ood_thr

    def predict(self, text, thrs=None):
        r = super().predict(text, thrs or self.thrs)
        r["trigger"] = None
        r["novel_flag"] = self.is_novel(text)
        return r

    def add_class(self, samples_new, texts_all=None):
        """在线学习: 新类样本到达, 增量更新原型(不重训 W)。"""
        new_types = sorted({e["type"] for s in samples_new for e in s["events"]})
        for ty in new_types:
            self.types.append(ty)
        Z = np.stack([self.encode(s["text"]) for s in samples_new])
        Y = np.zeros((len(samples_new), len(self.types)))
        for i, s in enumerate(samples_new):
            for e in s["events"]:
                Y[i, self.types.index(e["type"])] = 1
        mu_new = self._protos(Z, Y)
        # 合并: 旧原型保留, 新类取新样本原型
        self.mu = np.vstack([self.mu, mu_new[len(self.mu):]]) if len(new_types) else self.mu
        self.mu = self.mu[:len(self.types)]
        self.mu_n = self.mu / (np.linalg.norm(self.mu, axis=1, keepdims=True) + 1e-8)
        return self


def _softmax(x):
    x = x - x.max(axis=1, keepdims=True)
    e = np.exp(x)
    return e / (e.sum(axis=1, keepdims=True) + 1e-12)


# ================= M5 GoLLIE-lite (schema 引导匹配) =================
class GoLLIELite(BaseEE):
    """GoLLIE( guideline-following, ICLR 2024)机制的 CPU 轻量复现:
    每个事件类型用 schema 文本描述(类型名 + 高频触发词 + 论元角色表),
    文档与 schema 文本的字符 TF-IDF 余弦即类型得分。
    与 GoLLIE 的「代码化 schema 描述 + LLM 生成」对应, 保留 schema 先验匹配机制,
    原版需要微调 LLM(GPU), 本实现用于无 GPU 环境下的机制级对比。"""
    name = "GoLLIE-lite"
    def fit(self, train, valid=None):
        from collections import Counter
        texts = [s["text"] for s in train]
        self.vec = build_vectorizer(texts, max_features=40000)
        trig = defaultdict(Counter); roles = defaultdict(set)
        for s in train:
            for e in s["events"]:
                if e.get("trigger"):
                    trig[e["type"]][e["trigger"]] += 1
                for a in e.get("arguments") or []:
                    roles[e["type"]].add(a.get("role", ""))
        self.types = sorted(trig)
        schema_texts = []
        self.trig_words = {}
        for t in self.types:
            ws = [w for w, _ in trig[t].most_common(30)]
            self.trig_words[t] = ws
            schema_texts.append(t + " 事件: 触发词 " + " ".join(ws)
                                + " 论元角色 " + " ".join(sorted(roles[t])))
        S = self.vec.transform(schema_texts).toarray()
        self.S = S / (np.linalg.norm(S, axis=1, keepdims=True) + 1e-9)
        if valid:
            sbc = {t: ([], []) for t in self.types}
            for s in valid:
                sc = self.predict_scores(s["text"])
                gt = {e["type"] for e in s["events"]}
                for t, v in sc.items():
                    sbc[t][0 if t in gt else 1].append(v)
            self.thrs = _auto_threshold(sbc, valid)
            nv = [self.novelty_score(s["text"]) for s in valid]
            self.ood_thr = float(np.quantile(nv, 0.85))
        else:
            self.thrs = {t: 0.1 for t in self.types}
            self.ood_thr = 1.0
        return self
    def predict_scores(self, text):
        v = self.vec.transform([text]).toarray()[0]
        nv = np.linalg.norm(v)
        out = {}
        for j, t in enumerate(self.types):
            cos = float(self.S[j] @ v / nv) if nv else 0.0
            # schema 触发词重合度(归一化): 与 GoLLIE「按 schema 逐条匹配」机制对应
            ws = self.trig_words[t]
            hits = sum(1 for w in ws if w in text)
            cov = hits / len(ws) if ws else 0.0
            out[t] = 0.5 * max(cos, 0.0) + 0.5 * cov
        return out
    def novelty_score(self, text):
        return -max(self.predict_scores(text).values(), default=0.0)


# ================= M6 Text2Event-lite (管线抽取) =================
class Text2EventLite(BaseEE):
    """Text2Event(Qin et al., ACL 2021)结构生成范式的 CPU 轻量复现:
    stage1 触发词检测(类型触发词画像 token 打分, 对应 seq2seq 的触发词解码);
    stage2 触发词条件类型分类(触发词上下文窗口的 OvR 逻辑回归, 对应事件类型解码)。
    保留「先检测触发结构、再决定类型」的管线机制, 原版为 T5/BART 微调(需 GPU)。"""
    name = "Text2Event-lite"
    def __init__(self, ctx_w=25, trig_thr=0.15, topk=5):
        self.ctx_w, self.trig_thr, self.topk = ctx_w, trig_thr, topk
    def _ctx(self, text, s, e):
        return text[max(0, s - self.ctx_w): e + self.ctx_w]
    def fit(self, train, valid=None):
        self.profile = TypeTriggerProfile(train)
        ctxs, tys = [], []
        for s in train:
            for e in s["events"]:
                if e.get("trig_off"):
                    ctxs.append(self._ctx(s["text"], e["trig_off"][0], e["trig_off"][1]))
                    tys.append(e["type"])
        self.types = sorted(set(tys))
        self.vec = build_vectorizer(ctxs, max_features=30000)
        X = self.vec.transform(ctxs)
        self.clfs = {}
        for ty in self.types:
            y = np.array([1 if t == ty else 0 for t in tys])
            if y.sum() < 2:
                continue
            clf = LogisticRegression(C=4.0, max_iter=1000, solver="liblinear")
            clf.fit(X, y)
            self.clfs[ty] = clf
        self._clf_types = sorted(self.clfs)
        if valid:
            sbc = {t: ([], []) for t in self.types}
            for s in valid:
                sc = self.predict_scores(s["text"])
                gt = {e["type"] for e in s["events"]}
                for t, v in sc.items():
                    sbc[t][0 if t in gt else 1].append(v)
            self.thrs = _auto_threshold(sbc, valid)
            self.ood_thr = 0.35
        else:
            self.thrs = {t: 0.3 for t in self.types}
            self.ood_thr = 0.5
        return self
    def _coef(self):
        """缓存 (W, b): 稀疏矩阵乘代替逐 clf predict_proba。"""
        key = tuple(self._clf_types)
        if getattr(self, "_Wbc", None) is None or self._Wbc[0] != key:
            import scipy.sparse as sp
            tl = self._clf_types
            if tl:
                W = sp.csr_matrix(np.stack([self.clfs[t].coef_[0] for t in tl]))
                b = np.array([self.clfs[t].intercept_[0] for t in tl])
            else:
                W, b = None, None
            self._Wbc = (key, W, b)
        return self._Wbc[1], self._Wbc[2]
    def predict_scores(self, text):
        sc = {t: 0.0 for t in self.types}
        W, b = self._coef()
        if W is None:
            return sc
        toks = self.profile.token_scores(text, self._clf_types)
        cands = sorted(toks, key=lambda x: -x[3])[:self.topk]
        for tok, span, _ty, prof in cands:
            if prof < self.trig_thr:
                continue
            x = self.vec.transform([self._ctx(text, span[0], span[1])])
            z = (W @ x.T).toarray().ravel() + b
            ps = 1.0 / (1.0 + np.exp(-z))
            for ty, p in zip(self._clf_types, ps):
                v = float(p) * prof
                if v > sc[ty]:
                    sc[ty] = v
        return sc
    def novelty_score(self, text):
        toks = self.profile.token_scores(text, self._clf_types or self.types)
        best = max((x[3] for x in toks), default=0.0)
        return 1.0 - best          # 无触发词候选 → 新类


# ================= M7 ProtoFuse (ours v2, 融合优化模型) =================
class ProtoFuseEE(BaseEE):
    """v1(ProtoCon) 三项缺陷的针对性优化:
    (1) 表征容量不足 → TF-IDF 经 SVD 压缩为稠密 L2 表征(dim=128), 同时服务判别与原型;
    (2) 封闭集/开放集能力解耦 → 双头融合得分 s = α·sigmoid(LR) + (1-α)·cos(z, μ_c),
        α 在验证集上按 micro-F1 自动搜索;
    (3) 域内新类检测弱(v1 仅文档级余弦) → 新颖性融合触发词画像散度:
        novelty = β·(1-max cos(z,μ)) + (1-β)·(1-max token 画像分) —— 吸收词典「无命中」
        信号在域内稀有类上的优势(v1 实验 F1 最高), 即 ConACE 式上下文/词法感知的对比得分;
    (4) OOD 阈值自适应 → 按目标标记率(flag_rate)在验证分布上校准, 替代 v1 固定 q90。
    在线增量: add_class() 仅更新原型与 schema, 判别头不重训。"""
    name = "ProtoFuse"
    def __init__(self, dim=128, alpha=0.6, beta=0.5, flag_rate=0.15,
                 seed=42, max_features=40000):
        self.dim, self.alpha, self.beta, self.flag_rate = dim, alpha, beta, flag_rate
        self.seed, self.max_features = seed, max_features
    def fit(self, train, valid=None):
        from sklearn.decomposition import TruncatedSVD
        texts = [s["text"] for s in train]
        self.vec = build_vectorizer(texts, max_features=self.max_features)
        Xs = self.vec.transform(texts)
        n_comp = min(self.dim, Xs.shape[0] - 1, Xs.shape[1])
        self.svd = TruncatedSVD(n_components=n_comp, random_state=self.seed)
        Z = self.svd.fit_transform(Xs)
        Z = Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-9)
        self.types = sorted({e["type"] for s in train for e in s["events"]})
        k = len(self.types)
        Y = np.zeros((len(train), k))
        for i, s in enumerate(train):
            for e in s["events"]:
                Y[i, self.types.index(e["type"])] = 1
        # 原型头
        self.mu = np.stack([Z[Y[:, j] > 0].mean(axis=0) if Y[:, j].any() else np.zeros(n_comp)
                            for j in range(k)])
        self.mu_n = self.mu / (np.linalg.norm(self.mu, axis=1, keepdims=True) + 1e-9)
        # 判别头(稠密低维, 训练快)
        self.clfs = {}
        for j, ty in enumerate(self.types):
            if Y[:, j].sum() < 2:
                continue
            clf = LogisticRegression(C=4.0, max_iter=500, solver="lbfgs")
            clf.fit(Z, Y[:, j])
            self.clfs[ty] = clf
        # 触发词画像(新颖性门控)
        self.profile = TypeTriggerProfile(train)
        # 验证集: 融合权重 α + 类阈值 + OOD 阈值 (批量向量化, 避免逐文档 SVD)
        if valid:
            from .evaluate import multilabel_f1
            Zv = self.svd.transform(self.vec.transform([s["text"] for s in valid]))
            Zv = Zv / (np.linalg.norm(Zv, axis=1, keepdims=True) + 1e-9)
            k = len(self.types)
            L = np.zeros((len(valid), k))
            for j, ty in enumerate(self.types):
                clf = self.clfs.get(ty)
                if clf is not None:
                    L[:, j] = 1.0 / (1.0 + np.exp(-(Zv @ clf.coef_[0] + clf.intercept_[0])))
            C = np.clip(Zv @ self.mu_n.T, 0, None)
            golds = [{e["type"] for e in s["events"]} for s in valid]
            best = (self.alpha, -1)
            for a in np.arange(0.0, 1.01, 0.1):
                Fm = a * L + (1 - a) * C
                preds = [{self.types[j] for j in range(k) if Fm[i, j] >= 0.5}
                         for i in range(len(valid))]
                f1 = multilabel_f1(preds, golds)["micro_f1"]
                if f1 > best[1]:
                    best = (round(float(a), 2), f1)
            self.alpha = best[0]
            a = self.alpha
            sbc = {t: ([], []) for t in self.types}
            for i, s in enumerate(valid):
                gt = golds[i]
                for j, t in enumerate(self.types):
                    sbc[t][0 if t in gt else 1].append(float(a * L[i, j] + (1 - a) * C[i, j]))
            self.thrs = _auto_threshold(sbc, valid)
            nv = [self.novelty_score(s["text"]) for s in valid]
            self.ood_thr = float(np.quantile(nv, 1 - self.flag_rate))
        else:
            self.thrs = {t: 0.5 for t in self.types}
            self.ood_thr = 0.5
        return self
    def encode(self, text):
        if getattr(self, "_memo", None) is not None and self._memo[0] == text:
            return self._memo[1]
        z = self.svd.transform(self.vec.transform([text])).ravel()
        z = z / (np.linalg.norm(z) + 1e-9)
        self._memo = (text, z)
        return z
    def _lr_scores(self, z):
        out = {}
        for ty, clf in self.clfs.items():
            out[ty] = float(1.0 / (1.0 + np.exp(-(clf.coef_[0] @ z + clf.intercept_[0]))))
        return out
    def _fused_scores(self, text, alpha):
        z = self.encode(text)
        lr = self._lr_scores(z)
        cos = np.clip(self.mu_n @ z, 0, None)
        return {t: alpha * lr.get(t, 0.0) + (1 - alpha) * float(cos[j])
                for j, t in enumerate(self.types)}
    def predict_scores(self, text):
        return self._fused_scores(text, self.alpha)
    def predict_batch(self, texts):
        """批量类型预测(评测用): 返回每文档的预测类型列表。"""
        Z = self.svd.transform(self.vec.transform(list(texts)))
        Z = Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-9)
        k = len(self.types)
        L = np.zeros((len(texts), k))
        for j, ty in enumerate(self.types):
            clf = self.clfs.get(ty)
            if clf is not None:
                L[:, j] = 1.0 / (1.0 + np.exp(-(Z @ clf.coef_[0] + clf.intercept_[0])))
        C = np.clip(Z @ self.mu_n.T, 0, None)
        Fm = self.alpha * L + (1 - self.alpha) * C
        out = []
        for i in range(len(texts)):
            out.append([self.types[j] for j in range(k)
                        if Fm[i, j] >= self.thrs.get(self.types[j], 0.5)])
        return out
    def novelty_scores(self, texts):
        """批量新颖性打分(评测用): SVD 批量变换, 触发画像逐条(纯 python, 快)。"""
        Z = self.svd.transform(self.vec.transform(list(texts)))
        Z = Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-9)
        cosv = np.max(np.clip(Z @ self.mu_n.T, -1, 1), axis=1)
        trig = np.array([max((x[3] for x in self.profile.token_scores(t, self.types)), default=0.0)
                         for t in texts])
        return self.beta * (1 - cosv) + (1 - self.beta) * (1 - trig)
    def novelty_score(self, text):
        z = self.encode(text)
        cosv = float(np.max(self.mu_n @ z))
        toks = self.profile.token_scores(text, self.types)
        trig = max((x[3] for x in toks), default=0.0)
        return self.beta * (1 - cosv) + (1 - self.beta) * (1 - trig)
    def add_class(self, samples_new):
        new_types = sorted({e["type"] for s in samples_new for e in s["events"]} - set(self.types))
        if not new_types:
            return self
        Z = np.stack([self.encode(s["text"]) for s in samples_new])
        for ty in new_types:
            self.types.append(ty)
        Y = np.zeros((len(samples_new), len(self.types)))
        for i, s in enumerate(samples_new):
            for e in s["events"]:
                Y[i, self.types.index(e["type"])] = 1
        mu_new = np.stack([Z[Y[:, j] > 0].mean(axis=0) if Y[:, j].any()
                           else np.zeros(Z.shape[1]) for j in range(len(self.types))])
        self.mu = np.vstack([self.mu, mu_new[len(self.mu):]])
        self.mu_n = self.mu / (np.linalg.norm(self.mu, axis=1, keepdims=True) + 1e-9)
        for ty in new_types:
            self.thrs[ty] = 0.3
        return self


# ================= M8 ProtoCal (ours v3.2, 句子级双通道 + LOTO 验证) =================
_SENT_SPLIT = __import__("re").compile(r"[^。！？!?\n]+[。！？!?]?")

def _sents(t):
    ss = [s.strip() for s in _SENT_SPLIT.findall(t) if len(s.strip()) >= 6]
    return ss or [t]


class ProtoCalEE(ProtoFuseEE):
    """域内新类检测: 句子级双通道新颖性 (v3.2).

    诊断驱动设计(v2/v3.0/v3.1 迭代实证, 见 bench_report):
      - 文档级信号诊断: 对比表征距离 R_doc AUROC 0.631(唯一有效),
        SVD 距离 0.358 / 词典命中 0.412 均为反向信号 → v2 固定融合
        正权重混入反向信号是域内 AUROC 0.39 崩溃的根因;
      - 新类文档可与已知类事件共存(多标签), 文档级信号被已知部分污染;
      - 事件是局部结构(EE 独有先验): 新颖性在句子粒度可分 ——
        S_sent[q75] 反向 0.644, R_sent_max 0.634, 组合 0.665.
    设计:
      通道 R(表征): 句子级对比投影距离, 文档聚合取 max(最陌生句子);
      通道 S(结构): 句子级触发词典命中缺口(1-exp(-hits)), q75 聚合;
      融合: 双通道秩归一等权(避免 LOTO 在文档级学出倒置权重);
      阈值: 已知验证文档分位(1-flag_rate), 先验无关;
      LOTO: 仅作事后通道有效性验证(报告 per-type 单通道 AUC).
    消融模式: dual(默认)/r_only/s_only/fixed(=v2 ProtoFuse 文档级)."""
    name = "ProtoCal"
    def __init__(self, mode="dual", min_type_docs=8, neg_ratio=2, cap_pos=1000,
                 pcon_epochs=12, **kw):
        super().__init__(**kw)
        self.mode, self.min_type_docs = mode, min_type_docs
        self.neg_ratio, self.cap_pos, self.pcon_epochs = neg_ratio, cap_pos, pcon_epochs
    # ---- 通道 ----
    def _pcon_encode(self, texts, bs=2048):
        X = self.pcon.vec.transform(list(texts))
        out = []
        for b0 in range(0, X.shape[0], bs):
            out.append(np.maximum(np.asarray(X[b0:b0 + bs].todense(), np.float32)
                                  @ self.pcon.W, 0))
        Z = np.vstack(out) if out else np.zeros((0, self.pcon.dim))
        return Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-8)
    def _lex_hits(self, text, lex=None):
        lex = self.lex if lex is None else lex
        mx = 0
        for ws in lex.values():
            h = 0
            for w in ws:
                if w in text:
                    h += 1
            if h > mx:
                mx = h
        return mx
    def _doc_channels(self, texts):
        """返回 (R_sent_max, S_gap_q75) 每文档."""
        sents, owner = [], []
        for i, t in enumerate(texts):
            ss = _sents(t)
            sents.extend(ss)
            owner.extend([i] * len(ss))
        owner = np.array(owner)
        Z = self._pcon_encode(sents)
        Rs = 1.0 - np.max(np.clip(Z @ self.pcon.mu_n.T, -1, 1), axis=1)
        Ss = np.array([self._lex_hits(s) for s in sents])
        n = len(texts)
        R = np.zeros(n); G = np.zeros(n)
        for i in range(n):
            v = Rs[owner == i]; h = Ss[owner == i]
            R[i] = v.max() if len(v) else 0.0
            G[i] = np.exp(-np.quantile(h, 0.75)) if len(h) else 0.0
        return R, G
    # ---- 训练 ----
    def fit(self, train, valid=None):
        super().fit(train, valid)
        # 封闭集头解耦(v3.3): SVD 压缩损失判别信息(E1 75.8 vs Softmax 81.9),
        # 封闭抽取改用全稀疏 TF-IDF 逐类型 LR(= Softmax 头), 与新颖性检测头独立。
        self._sm_head = SoftmaxEE()
        self._sm_head.fit(train, valid)
        self.pcon = ProtoConEE(epochs=self.pcon_epochs)
        self.pcon.fit(train, valid)
        self.lex = build_trigger_lexicon(train)
        if self.mode == "fixed":
            return self
        # 阈值: 已知验证文档分位(先验无关)
        pool = valid if valid else train
        nv = self.novelty_scores([s["text"] for s in pool])
        self.ood_thr = float(np.quantile(nv, 1 - self.flag_rate))
        # LOTO 事后验证(不参与推理, 仅记录 per-type 单通道 AUC)
        self.loto_report = self._loto_report(train)
        return self
    # ---- 封闭集推理: regime 感知抽取头(与新颖性门控同构) ----
    # 域内(判别头最优): Softmax 稀疏 LR; 跨域(判别头过拟合源域词法):
    # ProtoFuse 融合头(原型分量对协变量偏移稳健)。
    # 流级 regime 由批量入口(novelty_scores/predict_batch)估计并缓存,
    # 无缓存时保守取域内判别头(封闭集场景)。
    def _head_types(self, text):
        if getattr(self, "_rho_cache", None) is not None and self._rho_cache <= 0.25:
            fs = self._fused_scores(text, self.alpha)
            return sorted(t for t, s in fs.items() if s >= self.thrs.get(t, 0.5))
        return list(self._sm_head.predict(text)["types"])
    def predict_scores(self, text):
        return self._sm_head.predict_scores(text)
    def predict(self, text, thrs=None):
        r = self._sm_head.predict(text, thrs)
        r["types"] = self._head_types(text)
        return r
    def predict_batch(self, texts):
        # 批量入口: 同步估计流级 regime(双通道秩一致性 ρ)
        try:
            R, G = self._doc_channels(texts)
            from scipy.stats import rankdata as _rk
            n = len(texts)
            rR, rG = _rk(R) / n, _rk(G) / n
            self._rho_cache = float(np.corrcoef(rR, rG)[0, 1]) if n > 2 else 1.0
        except Exception:
            pass
        return [self._head_types(t) for t in texts]
    def _loto_report(self, train):
        from sklearn.metrics import roc_auc_score as _auc
        Ztr = self._pcon_encode([s["text"] for s in train])
        tys_of = [{e["type"] for e in s["events"]} for s in train]
        rng = np.random.default_rng(0)
        rep = {}
        for t in sorted(self.lex):
            pos = [i for i, ts in enumerate(tys_of) if ts == {t}]
            keep = [i for i, ts in enumerate(tys_of) if t not in ts]
            if len(pos) < self.min_type_docs or not keep:
                continue
            rng.shuffle(pos)
            pos = pos[:self.cap_pos]
            neg = list(rng.choice(keep, min(self.neg_ratio * len(pos), len(keep)),
                                  replace=False))
            stypes = [u for u in sorted(self.lex)
                      if u != t and any(u in tys_of[i] for i in keep)]
            if not stypes:
                continue
            mu = np.stack([Ztr[[i for i in keep if u in tys_of[i]]].mean(axis=0)
                           for u in stypes])
            mu_n = mu / (np.linalg.norm(mu, axis=1, keepdims=True) + 1e-9)
            if np.isnan(mu_n).any():
                continue
            slex = {u: self.lex[u] for u in stypes}
            idx = pos + neg
            yy = np.array([1] * len(pos) + [0] * len(neg))
            r_ = 1.0 - np.max(np.clip(mu_n @ Ztr[idx].T, -1, 1), axis=1)
            # 句子级 S(与推理一致): shadow 词典命中缺口
            sg = []
            for i in idx:
                h = [self._lex_hits(s, slex) for s in _sents(train[i]["text"])]
                sg.append(1.0 - np.exp(-np.quantile(h, 0.75)) if h else 0.0)
            sg = np.array(sg)
            try:
                rep[t] = {"n_pos": len(pos), "R_auc": round(float(_auc(yy, r_)), 3),
                          "S_auc": round(float(_auc(yy, sg)), 3)}
            except ValueError:
                pass
        return rep
    # ---- 推理 ----
    def novelty_embeddings(self, texts, topk=3):
        """新颖性聚焦文档嵌入(供新类聚类): R 最大的 topk 句子表征均值, 剥离已知部分.

        动机: 文档级嵌入被共存已知类事件主导(与检测通道同源污染),
        novel_group 聚类需聚焦文档中最陌生句子的表征.
        """
        if self.mode == "fixed" or not hasattr(self, "pcon"):
            return None
        sents, owner = [], []
        for i, t in enumerate(texts):
            ss = _sents(t)
            sents.extend(ss)
            owner.extend([i] * len(ss))
        owner = np.array(owner)
        Z = self._pcon_encode(sents)
        Rs = 1.0 - np.max(np.clip(Z @ self.pcon.mu_n.T, -1, 1), axis=1)
        out = np.zeros((len(texts), Z.shape[1]))
        for i in range(len(texts)):
            gi = np.where(owner == i)[0]
            if not len(gi):
                continue
            v = Rs[gi]
            k = max(1, min(topk, len(v)))
            sel = gi[np.argsort(-v)[:k]]
            z = Z[sel].mean(axis=0)
            n = np.linalg.norm(z)
            out[i] = z / n if n > 0 else 0.0
        return out
    def novelty_scores(self, texts):
        if self.mode == "fixed" or not hasattr(self, "pcon"):
            return super().novelty_scores(texts)
        R, G = self._doc_channels(texts)
        if self.mode == "r_only":
            return R
        if self.mode == "s_only":
            return G
        # 句子级双通道秩归一融合
        from scipy.stats import rankdata as _rk
        n = len(texts)
        rR, rG = _rk(R) / n, _rk(G) / n
        F_sent = (rR + rG) / 2
        # 粒度自适应门控(v3.3): 域内(概念偏移)信号在句子级, 跨域(协变量偏移)
        # 信号在文档级 —— 由测试流自身的双通道秩一致性 ρ 无标签识别 regime:
        #   ρ 高(域内, 实测 0.45) → 句子级双通道; ρ 低(跨域, 实测 0.06) → 文档级融合.
        # 硬门控阈值 τ_ρ=0.25 取在双峰间隙(0.06 vs 0.45)正中, 不接触新类标签.
        if not getattr(self, "grain_adaptive", True):
            return F_sent
        rho = float(np.corrcoef(rR, rG)[0, 1]) if n > 2 else 1.0
        self._rho_cache = rho  # 缓存流级 regime, 供抽取头选择
        if rho > 0.25:
            return F_sent
        # 跨域 regime: 文档级融合新颖性(= ProtoFuse, 跨域近饱和)
        nv_doc = super().novelty_scores(texts)
        return _rk(nv_doc) / n
    def novelty_score(self, text):
        return float(self.novelty_scores([text])[0])


# ================= OOD 检测器移植基线 (标准方法在 EE 上的对照) =================
class KNNOODEE(ProtoConEE):
    """KNN-OOD (Sun et al., ICML'22) 移植: k 近邻余弦距离, ProtoCon 表征空间."""
    name = "KNN-OOD"
    def __init__(self, k=5, flag_rate=0.15, **kw):
        super().__init__(**kw)
        self.k = k
        self.flag_rate = flag_rate
    def _batch_encode(self, texts, bs=2048):
        X = self.vec.transform(list(texts))
        out = [np.maximum(np.asarray(X[i:i + bs].todense(), np.float32) @ self.W, 0)
               for i in range(0, X.shape[0], bs)]
        Z = np.vstack(out)
        return Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-8)
    def fit(self, train, valid=None):
        super().fit(train, valid)
        self._Ztr = self._batch_encode([s["text"] for s in train])
        pool = valid if valid else train
        nv = self.novelty_scores([s["text"] for s in pool])
        self.ood_thr = float(np.quantile(nv, 1 - self.flag_rate))
        return self
    def novelty_scores(self, texts):
        sims = self._batch_encode(texts) @ self._Ztr.T
        kth = np.sort(sims, axis=1)[:, -self.k]
        return 1.0 - kth


class MahalanEE(ProtoConEE):
    """类条件 Mahalanobis (Lee et al., NeurIPS'18) 移植: Ledoit-Wolf 共享协方差."""
    name = "Mahalanobis"
    def __init__(self, flag_rate=0.15, **kw):
        super().__init__(**kw)
        self.flag_rate = flag_rate
    def fit(self, train, valid=None):
        super().fit(train, valid)
        from sklearn.covariance import LedoitWolf
        Z = self._batch_encode_internal([s["text"] for s in train])
        tys = [{e["type"] for e in s["events"]} for s in train]
        mus = []
        for u in self.types:
            idx = [i for i in range(len(train)) if u in tys[i]]
            mus.append(Z[idx].mean(axis=0) if idx else np.zeros(Z.shape[1]))
        self._mu = np.stack(mus)
        lw = LedoitWolf().fit(Z)
        self._P = lw.precision_
        pool = valid if valid else train
        nv = self.novelty_scores([s["text"] for s in pool])
        self.ood_thr = float(np.quantile(nv, 1 - self.flag_rate))
        return self
    def _batch_encode_internal(self, texts, bs=2048):
        X = self.vec.transform(list(texts))
        out = [np.maximum(np.asarray(X[i:i + bs].todense(), np.float32) @ self.W, 0)
               for i in range(0, X.shape[0], bs)]
        Z = np.vstack(out)
        return Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-8)
    def novelty_scores(self, texts):
        Z = self._batch_encode_internal(texts)
        D = np.stack([np.sum(((Z - mu) @ self._P) * (Z - mu), axis=1)
                      for mu in self._mu], axis=1)
        return D.min(axis=1)


class EnergyEE(SoftmaxEE):
    """Energy score (Liu et al., NeurIPS'20) 移植: 逐类型二元 logit 上的 -logsumexp(近似)."""
    name = "Energy"
    def novelty_scores(self, texts):
        from scipy.special import logsumexp
        X = self.vec.transform(list(texts))
        zs = np.stack([self.clfs[t].decision_function(X) for t in self._clf_types], axis=1)
        return -logsumexp(zs, axis=1)
