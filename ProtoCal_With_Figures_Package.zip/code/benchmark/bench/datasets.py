"""统一格式加载器与基准构建。

统一样本格式:
{
  "id": str,
  "text": str,                       # 文档/句子全文
  "domain": str,                     # cmnee / cmnie / ceef
  "events": [                        # 金标事件(可为空 = 负样本)
    {"type": str,
     "trigger": str, "trig_off": [s, e],          # 字符偏移; ceef/cmnee 有, cmnie 为 token 偏移转字符
     "arguments": [{"role": str, "text": str, "off": [s, e]}]
    }
  ],
  "chunks": [...]                    # 仅 ceef: [{"chunk_id","modality","text"}]
}
"""
from __future__ import annotations

import json
import os
import re
from collections import Counter
from typing import Dict, List

RAW = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "raw")
DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

# ---- 开放世界协议: 留出的新类(各数据集中训练样本最少的类型) ----
CMNEE_NOVEL = {"Injure", "Conflict"}
CMNIE_NOVEL = {"Indemnity", "Support"}
CEEF_NOVEL = {"social.无人机扰航", "finance.数据资产入表", "social.数据泄露", "finance.绿色债券"}


# ================= B1 CMNEE (文档级) =================
def load_cmnee(split: str) -> List[Dict]:
    path = os.path.join(RAW, f"cmnee_{split}.json")
    out = []
    for x in json.load(open(path, encoding="utf-8")):
        events = []
        for ev in x.get("event_list", []):
            trig = ev.get("trigger") or {}
            args = [{"role": a["role"], "text": a["text"], "off": a["offset"]}
                    for a in ev.get("arguments", [])]
            events.append({"type": ev["event_type"], "trigger": trig.get("text", ""),
                           "trig_off": trig.get("offset"), "arguments": args})
        out.append({"id": f"cmnee-{split}-{x['id']}", "text": x["text"],
                    "domain": "cmnee", "events": events, "chunks": []})
    return out


# ================= B2 CMNIE (句子级, token 偏移) =================
def _tok_off_to_char(text: str, tokens: List[str], tok_off: List[int]):
    """CMNIE 偏移为 token 索引; 顺序扫描累计字符位置。"""
    pos, tok_spans = 0, []
    for t in tokens:
        i = text.find(t, pos)
        if i < 0:
            tok_spans.append((pos, pos + len(t)))
            pos = pos + len(t)
        else:
            tok_spans.append((i, i + len(t)))
            pos = i + len(t)
    if not tok_off:
        return None
    s, e = tok_off
    if s >= len(tok_spans) or e > len(tok_spans) or s > e:
        return None
    return [tok_spans[s][0], tok_spans[min(e - 1, len(tok_spans) - 1)][1]]


def load_cmnie(split: str) -> List[Dict]:
    fname = {"train": "cmnie_train.json", "valid": "cmnie_dev.json", "test": "cmnie_test.json"}[split]
    out = []
    for line in open(os.path.join(RAW, fname), encoding="utf-8"):
        x = json.loads(line)
        em = x.get("event_mention") or {}
        events = []
        if em.get("event_type"):
            trig = em.get("trigger") or {}
            off = _tok_off_to_char(x["sentence"], x.get("tokens", []), trig.get("offset"))
            args = []
            for a in em.get("arguments", []):
                aoff = _tok_off_to_char(x["sentence"], x.get("tokens", []), a.get("offset"))
                args.append({"role": a["role"], "text": a["text"], "off": aoff})
            events.append({"type": em["event_type"], "trigger": trig.get("text", ""),
                           "trig_off": off, "arguments": args})
        out.append({"id": f"cmnie-{split}-{x['id'][:12]}", "text": x["sentence"],
                    "domain": "cmnie", "events": events, "chunks": []})
    return out


# ================= B4 CEEF (构造: 多模态证据) =================
def _parse_markers(text: str, events_spec: List[Dict]) -> Dict:
    """解析扩展标注格式:
    正文使用 ⟪触发词⟫ 与 ⟦角色=值⟧ 标记, 构建器去除标记并计算字符偏移。
    events_spec: [{"type": ..., "trigger": "试验", "args": [["Subject","某部"], ...], "evidence": [0,2]}]
    """
    # 提取并去除所有标记, 记录每个标记在干净文本中的偏移
    clean, marks = [], []
    i = 0
    pat = re.compile(r"⟪(.+?)⟫|⟦(.+?)=(.+?)[⟧⟫]")   # 闭合符容错 ⟧/⟫
    last = 0
    for m in pat.finditer(text):
        clean.append(text[last:m.start()])
        base = sum(len(c) for c in clean)
        if m.group(1) is not None:
            marks.append(("T", m.group(1), base, base + len(m.group(1))))
            clean.append(m.group(1))
        else:
            marks.append(("A", m.group(2), m.group(3), base, base + len(m.group(3))))
            clean.append(m.group(3))
        last = m.end()
    clean.append(text[last:])
    doc = "".join(clean)

    events = []
    used = set()
    for spec in events_spec:
        # 找到与 spec 匹配的触发词标记(文本相同且未用)
        tri = None
        for idx, mk in enumerate(marks):
            if mk[0] == "T" and mk[1] == spec["trigger"] and idx not in used:
                tri = (idx, [mk[2], mk[3]]); used.add(idx); break
        if tri is None:
            continue
        args = []
        for role, val in spec.get("args", []):
            for idx, mk in enumerate(marks):
                if mk[0] == "A" and mk[1] == role and mk[2] == val and idx not in used:
                    args.append({"role": role, "text": val, "off": [mk[3], mk[4]]}); used.add(idx); break
        events.append({"type": spec["type"], "trigger": spec["trigger"], "trig_off": tri[1],
                       "arguments": args, "evidence_pages": spec.get("evidence", [])})
    return {"text": doc, "events": events}


def load_ceef() -> List[Dict]:
    """CEEF-Evidence: 扩展标注多模态文档(文本页/表格页/图片说明页)。"""
    src = json.load(open(os.path.join(DATA, "ceef_ext.json"), encoding="utf-8"))
    out = []
    for x in src:
        parsed = _parse_markers(x["text"], x.get("events", []))
        chunks = []
        for pi, page in enumerate(x.get("pages", [])):
            chunks.append({"chunk_id": f"{x['id']}-p{pi}", "modality": page["modality"],
                           "text": page["text"], "page": pi})
        for ev in parsed["events"]:
            # 证据块金标: 事件标记来源页(spec.evidence) + 触发词实际所在页(双保险)
            trig_page = None
            for c in chunks:
                if ev["trigger"] and ev["trigger"] in c["text"]:
                    trig_page = c["page"]; break
            pages = set(ev.get("evidence_pages") or [])
            if trig_page is not None:
                pages.add(trig_page)
            ev["gold_chunks"] = sorted(pages)
        out.append({"id": x["id"], "text": parsed["text"], "domain": "ceef",
                    "events": parsed["events"], "chunks": chunks,
                    "doc_group": x.get("doc_group", "ext")})
    return out


# ================= B4+ CEEF-Large (扩充证据评测集) =================
def build_ceef_large(n_auto=60, seed=11, min_chunks=3, max_events=3):
    """CEEF-Large = 24 篇人工多模态文档 + n_auto 篇自动构造多块文档(源自 CMNEE 测试集,
    公开数据集的真实触发词/论元金标, 按句分组切成 3-8 个证据块)。
    证据块金标 = 与触发词或任一论元 span 重叠的块(自动派生, 真实偏移)。"""
    import random as _random
    rng = _random.Random(seed)
    out = load_ceef()                                   # 24 篇人工多模态
    te = load_cmnee("test")
    idxs = [i for i in range(len(te)) if len(te[i]["text"]) >= 300
            and any(e.get("trig_off") for e in te[i]["events"])]
    rng.shuffle(idxs)
    n_added = 0
    for i in idxs:
        if n_added >= n_auto:
            break
        s = te[i]
        text = s["text"]
        sents = [x for x in re.split(r"(?<=[。！？!?])", text) if x != ""]
        if len(sents) < min_chunks:
            continue
        target_len = max(100, len(text) // rng.randint(4, 8))
        chunks, cur = [], ""
        for sent in sents:
            if cur and len(cur) + len(sent) > target_len:
                chunks.append(cur); cur = sent
            else:
                cur += sent
        if cur:
            chunks.append(cur)
        if len(chunks) < min_chunks:
            continue
        # 保证拼接等于原文(偏移才能成立)
        assert "".join(chunks) == text, f"chunking broke text: {s['id']}"
        spans, pos = [], 0
        for c in chunks:
            spans.append((pos, pos + len(c))); pos += len(c)
        events = []
        for e in s["events"][:max_events]:
            if not e.get("trig_off"):
                continue
            gold = set()
            for off in [e["trig_off"]] + [a["off"] for a in e["arguments"] if a.get("off")]:
                for ci, (cs, ce) in enumerate(spans):
                    if off[0] < ce and cs < off[1]:
                        gold.add(ci)
            if gold:
                events.append({**e, "gold_chunks": sorted(gold), "evidence_pages": sorted(gold)})
        if not events:
            continue
        did = s["id"].replace("cmnee-test-", "ceef-auto")
        out.append({"id": did, "text": text, "domain": "ceef-auto", "events": events,
                    "chunks": [{"chunk_id": f"{did}-p{ci}", "modality": "text",
                                "text": chunks[ci], "page": ci} for ci in range(len(chunks))],
                    "doc_group": "auto-known"})
        n_added += 1
    return out


# ================= B3 OWB (开放世界协议) =================
def build_owb(novel_cmnie: "set | None" = None):
    """train/valid = CMNEE∪CMNIE 已知类样本(剔除新类文档);
    test = 完整测试集(含新类)。返回 (train, valid, test, known_types, novel_types)。"""
    novel_cmnie = novel_cmnie or CMNIE_NOVEL
    tr = load_cmnee("train") + load_cmnie("train")
    va = load_cmnee("valid") + load_cmnie("valid")
    te = load_cmnee("test") + load_cmnie("test")

    def filt(samples, drop_novel: bool):
        out = []
        for s in samples:
            types = {e["type"] for e in s["events"]}
            if drop_novel and types & (CMNEE_NOVEL | novel_cmnie):
                continue  # 训练/验证阶段新类文档不可见
            out.append(s)
        return out

    train, valid, test = filt(tr, True), filt(va, True), te
    known = {e["type"] for s in train for e in s["events"]}
    novel = {e["type"] for s in test for e in s["events"]} - known
    return train, valid, test, known, novel


def stats(samples: List[Dict]) -> Dict:
    types = Counter(e["type"] for s in samples for e in s["events"])
    return {"n": len(samples), "with_events": sum(1 for s in samples if s["events"]),
            "events": sum(types.values()), "types": dict(types.most_common())}
