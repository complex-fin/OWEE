"""Auditable repairs to the supplied ProtoCal benchmark; no API/LLM calls."""
from pathlib import Path
import sys, hashlib, json
import numpy as np
from scipy.optimize import linear_sum_assignment
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score, adjusted_rand_score, normalized_mutual_info_score
from sklearn.decomposition import TruncatedSVD
sys.path.insert(0, str(Path(__file__).parent))
from benchmark.bench.models import ProtoCalEE, ProtoConEE, ProtoFuseEE, SoftmaxEE
from benchmark.bench.features import build_trigger_lexicon

GAMMA = .15

def ecdf(ref, values):
    return np.searchsorted(np.sort(ref), values, side='right') / len(ref)

def threshold(scores, gamma=GAMMA):
    n = len(scores); k = int(np.floor((n+1)*gamma))
    if k < 1: return float('inf'), k
    return float(np.sort(scores)[n-k]), k

def ks_low(values):
    """Exact supremum on [0,.5], accounting for both sides of ECDF jumps."""
    x=np.sort(np.asarray(values)); n=len(x)
    if not n: return 0.
    points=np.unique(np.r_[0., .5, x[(x>=0)&(x<=.5)]])
    right=np.searchsorted(x,points,side='right')/n
    left=np.searchsorted(x,points,side='left')/n
    # A left limit at zero lies outside the interval and is excluded.
    left[points==0]=right[points==0]
    return float(max(np.max(abs(right-points)),np.max(abs(left-points))))

def deduplicate_splits(train, valid, test):
    """Training first, then validation, then test; exact-text matches only."""
    seen=set(); splits=[]; removed=[]
    for samples in (train,valid,test):
        keep=[]; drop=[]
        for d in samples:
            h=hashlib.sha256(d['text'].encode()).hexdigest()
            if h in seen: drop.append(d['id'])
            else: seen.add(h); keep.append(d)
        splits.append(keep); removed.append(drop)
    return (*splits,removed)

class CorrectedProtoCal(ProtoCalEE):
    """Preserve supplied learned components, repair calibration/routing."""
    def __init__(self,seed=42):
        super().__init__(seed=seed); self.run_seed=seed; self.branch='sent'

    def fit(self,train,valid):
        ix=np.random.default_rng(123).permutation(len(valid)); h=len(ix)//2
        self.ref_idx=ix[:h]; self.cal_idx=ix[h:]
        ref=[valid[i] for i in self.ref_idx]
        # Learned score components never see V_cal. Extraction thresholds
        # may use V_ref, which is independent of the calibration half.
        ProtoFuseEE.fit(self,train,ref)
        self._sm_head=SoftmaxEE(); self._sm_head.fit(train,ref)
        self.pcon=ProtoConEE(epochs=12,seed=self.run_seed)
        self.pcon.fit(train,None)
        self.lex=build_trigger_lexicon(train)
        from benchmark.bench.models import _sents
        hits=[self._lex_hits(s) for d in train for s in _sents(d['text'])]
        self.gstar=max(1.,float(np.median(hits)))
        self.R_ref,self.G_ref=self.channels([d['text'] for d in ref])
        Rc,Gc=self.channels([valid[i]['text'] for i in self.cal_idx])
        self.rR_cal=ecdf(self.R_ref,Rc)
        f=.5*(self.rR_cal+ecdf(self.G_ref,Gc))
        self.tau,self.k=threshold(f);self.n_cal=len(f)
        self.cal_flag_rate=float(np.mean(f>self.tau))
        self.gate_null=ks_low(self.rR_cal)
        return self

    def channels(self,texts):
        from benchmark.bench.models import _sents
        sents=[]; starts=[0]
        for t in texts: sents.extend(_sents(t)); starts.append(len(sents))
        Z=self._pcon_encode(sents)
        rs=1-np.max(np.clip(Z@self.pcon.mu_n.T,-1,1),axis=1)
        gs=np.clip(1-np.array([self._lex_hits(s) for s in sents])/self.gstar,0,1)
        R=[];G=[]
        for a,b in zip(starts[:-1],starts[1:]):
            R.append(float(rs[a:b].max()));G.append(float(np.quantile(gs[a:b],.75)))
        return np.array(R),np.array(G)

    def novelty_scores(self,texts):
        if not hasattr(self,'R_ref'):return ProtoFuseEE.novelty_scores(self,texts)
        from scipy.stats import rankdata
        R,G=self.channels(texts);r=ecdf(self.R_ref,R)
        F=.5*(r+ecdf(self.G_ref,G))
        self.last_channels=(R,G,r,F)
        self.gate_stat=ks_low(r)
        self.branch='sent' if self.gate_stat<=max(.15,3*self.gate_null) else 'doc'
        if self.branch=='sent':return F
        return rankdata(ProtoFuseEE.novelty_scores(self,texts))/len(texts)

    def predict_batch(self,texts):
        if self.branch=='doc':return ProtoFuseEE.predict_batch(self,texts)
        # Scores in sparse batches avoid per-document transforms.
        sm=self._sm_head
        X=sm.vec.transform(list(texts)); ts=sm._clf_types
        W=np.vstack([sm.clfs[t].coef_[0] for t in ts]); b=np.array([sm.clfs[t].intercept_[0] for t in ts])
        from scipy.special import expit
        P=expit(X@W.T+b)
        return [[t for j,t in enumerate(ts) if P[i,j]>=sm.thrs[t]] for i in range(len(texts))]

def multilabel_counts(pred,gold):
    tp=sum(len(p&g) for p,g in zip(pred,gold))
    fp=sum(len(p-g) for p,g in zip(pred,gold))
    fn=sum(len(g-p) for p,g in zip(pred,gold))
    return dict(tp=tp,fp=fp,fn=fn,f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.)

def grouping(model,test,known,flags,save_path=None):
    """Cluster all flags; evaluate true sets, without dropping novel labels."""
    gold=[{e['type'] for e in d['events']}-known for d in test]
    p1=np.flatnonzero(flags);p2=np.array([i for i in p1 if gold[i]])
    total_labels=sum(map(len,gold))
    if len(p1)<3:return {'n_flagged':len(p1),'n_detected':len(p2),'status':'insufficient flags'}
    Z=np.nan_to_num(model.novelty_embeddings([test[i]['text'] for i in p1]))
    if Z.shape[1]>128:
        Z=TruncatedSVD(n_components=min(64,len(Z)-1),random_state=0).fit_transform(Z)
    zero=np.linalg.norm(Z,axis=1)==0
    if zero.any():Z[zero]=np.random.default_rng(0).normal(0,1e-6,(zero.sum(),Z.shape[1]))
    sample=np.arange(len(Z)) if len(Z)<=400 else np.random.default_rng(0).choice(len(Z),400,replace=False)
    best=None
    for k in range(2,min(8,len(Z)-1)+1):
        cl=AgglomerativeClustering(n_clusters=k,metric='cosine',linkage='average').fit_predict(Z)
        if len(np.unique(cl[sample]))<2:continue
        sil=silhouette_score(Z[sample],cl[sample],metric='cosine')
        if best is None or sil>best[0]:best=(sil,cl,k)
    sil,cl,k=best
    types=sorted(set().union(*gold));cont=np.zeros((k,len(types)),dtype=int)
    for pos,i in enumerate(p1):
        for t in gold[i]:cont[cl[pos],types.index(t)]+=1
    rows,cols=linear_sum_assignment(-cont)
    mapping={int(a):types[b] for a,b in zip(rows,cols) if cont[a,b]>0}
    # Every flag predicts one cluster label. Unmatched clusters remain false
    # positive predictions rather than disappearing from the denominator.
    pred=[set() for _ in test]
    for pos,i in enumerate(p1):pred[i]={mapping.get(int(cl[pos]),f'__unmatched_{cl[pos]}')}
    e2e=multilabel_counts(pred,gold)
    conditional=multilabel_counts([pred[i] for i in p2],[gold[i] for i in p2])
    # Standard ARI/NMI/purity only have a single gold partition: restrict
    # these diagnostic metrics to singly novel docs, keeping their clusters.
    singles=[pos for pos,i in enumerate(p1) if len(gold[i])==1]
    yy=[next(iter(gold[p1[pos]])) for pos in singles]; cc=cl[singles]
    from collections import Counter
    purity=sum(max(Counter(y for y,c0 in zip(yy,cc) if c0==c).values()) for c in set(cc))/len(yy) if yy else None
    # At most one correct label per flagged document, all flags predict one.
    bound=2*len(p2)/(len(p1)+total_labels)
    assert e2e['f1']<=bound+1e-12
    out=dict(k=k,silhouette=float(sil),n_flagged=len(p1),n_detected=len(p2),
             n_gold_novel=sum(bool(g) for g in gold),n_gold_labels=total_labels,
             n_single_novel_detected=len(yy),conditional=conditional,e2e=e2e,bound=bound,
             ari=float(adjusted_rand_score(yy,cc)) if yy else None,
             nmi=float(normalized_mutual_info_score(yy,cc)) if yy else None,purity=purity,mapping=mapping)
    if save_path:
        Path(save_path).write_text(json.dumps({'evaluation':out,'flagged_indices':p1.tolist(),
          'clusters':cl.tolist(),'predicted_labels':[sorted(p) for p in pred],
          'gold_labels':[sorted(g) for g in gold]},ensure_ascii=False,indent=2),encoding='utf8')
    return out
