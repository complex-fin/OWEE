"""Rebuild all manuscript figures from saved experimental outputs; no training."""
from pathlib import Path
import os,json,hashlib
BASE=Path(__file__).resolve().parent.parent
os.environ.setdefault('MPLCONFIGDIR',str(BASE/'figures/.mplconfig'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from matplotlib.lines import Line2D

OUT=BASE/'figures';OUT.mkdir(exist_ok=True)
D=json.loads((BASE/'results/results.json').read_text(encoding='utf8'))
P=D['protocal'];seeds=[r['seed'] for r in P]
COL=['#2166AC','#D07826','#237B5B'];GRAY='#6C7277'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':10,
 'axes.labelsize':9,'legend.fontsize':8,'xtick.labelsize':8,'ytick.labelsize':8,
 'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
manifest={'matplotlib':matplotlib.__version__,'numpy':np.__version__,'figures':[]}
def save(fig,name,sources):
    for ext in ['png','svg','pdf']:fig.savefig(OUT/f'{name}.{ext}',dpi=300,bbox_inches='tight',facecolor='white')
    plt.close(fig)
    manifest['figures'].append({'name':name,'sources':sources,'formats':['png','svg','pdf']})

def curves(y,s):
    y=np.asarray(y,bool);s=np.asarray(s,float)
    order=np.argsort(-s,kind='mergesort');ss=s[order];yy=y[order]
    at=np.r_[np.flatnonzero(np.diff(ss)),len(ss)-1]
    tp=np.cumsum(yy)[at];fp=1+at-tp
    tpr=np.r_[0,tp/y.sum()];fpr=np.r_[0,fp/(~y).sum()]
    precision=np.r_[1,tp/(tp+fp)];recall=np.r_[0,tp/y.sum()]
    auc=float(np.trapezoid(tpr,fpr))
    ap=float(np.sum(np.diff(recall)*precision[1:]))
    return fpr,tpr,recall,precision,auc,ap

# Figure 1. ProtoCal architecture: fitting resources and inference dataflow.
fig,ax=plt.subplots(figsize=(7.6,6.8));ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
def box(x,y,w,h,text,fc='#F2F5F8',ec='#60758B',size=9):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.008,rounding_size=0.012',linewidth=1,edgecolor=ec,facecolor=fc))
    ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size,linespacing=1.35)
def arrow(points,dashed=False,color='#536779'):
    for a,b in zip(points[:-2],points[1:-1]):
        ax.plot([a[0],b[0]],[a[1],b[1]],color=color,lw=1,ls='--' if dashed else '-')
    ax.add_patch(FancyArrowPatch(points[-2],points[-1],arrowstyle='-|>',mutation_scale=10,linewidth=1,color=color,linestyle='--' if dashed else '-'))
ax.text(.02,.99,'A   Fit using known-type documents',fontsize=11,weight='bold',va='top',color='#203C58')
box(.02,.83,.29,.10,'Training split\nRepresentation, prototypes,\nlexicons and prediction heads',size=8.7)
box(.355,.83,.29,.10,'Reference split  V_ref\nChannel ECDF transforms\nand known-head settings',size=8.7)
box(.69,.83,.29,.10,'Calibration split  V_cal\nOrder-statistic threshold τ\nand diagnostic null scale',size=8.7)
ax.plot([.02,.98],[.795,.795],color='#CFD8E0',lw=1)
ax.text(.02,.775,'B   Score and route an unlabeled test batch',fontsize=11,weight='bold',va='top',color='#203C58')
box(.02,.57,.16,.13,'Input batch\nDocuments\n↓\nSentences',size=9)
box(.245,.645,.275,.09,'Representation channel  R\nMaximum sentence–prototype gap',fc='#EAF2FB',ec='#2166AC',size=8.5)
box(.245,.505,.275,.09,'Trigger-gap channel  G\n75th percentile of sentence gaps',fc='#FFF3E7',ec='#D07826',size=8.5)
arrow([(.18,.635),(.21,.635),(.21,.69),(.235,.69)])
arrow([(.21,.635),(.21,.55),(.235,.55)])
box(.625,.585,.32,.125,'Sentence-level score\nReference ECDFs for R and G\nEqual-weight fusion F_sent',fc='#EAF4EF',ec='#237B5B',size=9)
arrow([(.52,.69),(.56,.69),(.56,.67),(.615,.67)])
arrow([(.52,.55),(.56,.55),(.56,.615),(.615,.615)])
box(.625,.395,.32,.115,'Batch routing diagnostic\nLower-half discrepancy D_low\nCompare with max(0.15, 3D₀)',size=8.8)
arrow([(.52,.69),(.54,.69),(.54,.455),(.615,.455)],True)
box(.245,.295,.275,.12,'Document-level score\nSVD prototype distance +\ntrigger-profile mismatch\nWithin-batch rank fusion',fc='#FFF3E7',ec='#D07826',size=8.5)
arrow([(.10,.57),(.10,.355),(.235,.355)])
box(.625,.205,.32,.12,'Select branch and apply τ\nRetain the matching\nknown-type prediction head',fc='#EAF4EF',ec='#237B5B',size=9)
arrow([(.945,.645),(.975,.645),(.975,.265),(.955,.265)])
arrow([(.785,.395),(.785,.335)],True)
arrow([(.52,.355),(.56,.355),(.56,.265),(.615,.265)])
box(.02,.035,.29,.095,'Document-level outputs\nNovelty flags + known types',size=8.8)
box(.355,.035,.29,.095,'Group flagged documents\nNovel-type candidate clusters',size=8.8)
box(.69,.035,.29,.095,'Analyst review\nInspect and name proposed types',size=8.8)
arrow([(.625,.225),(.595,.225),(.595,.165),(.165,.165),(.165,.14)])
arrow([(.31,.082),(.345,.082)])
arrow([(.645,.082),(.68,.082)])
ax.text(.02,.225,'Solid arrows: data / scores',fontsize=8,color='#536779')
ax.text(.02,.19,'Dashed arrows: diagnostic / control',fontsize=8,color='#536779')
fig.subplots_adjust(left=.005,right=.995,bottom=.005,top=.995)
save(fig,'fig1_architecture',['code/corrected_protocol.py','code/run_corrected.py'])

# Figure 2. Plot only the saved test scores; ties are kept together.
fig,axs=plt.subplots(1,2,figsize=(7.2,3.35),layout='constrained')
for seed in [7,2026]:
    z=np.load(BASE/f'results/scores_protocal_{seed}.npz');f,t,r,p,a,ap=curves(z['labels'],z['scores'])
    axs[0].plot(f,t,color=COL[0],alpha=.26,lw=1.1);axs[1].plot(r,p,color=COL[0],alpha=.26,lw=1.1)
for name,color,style in [('ProtoCal',COL[0],'-'),('Softmax','#222222','--'),('Energy',COL[1],'-.'),('ProtoCon',GRAY,':')]:
    path=BASE/('results/scores_protocal_42.npz' if name=='ProtoCal' else f'results/scores_{name}_42.npz')
    z=np.load(path);f,t,r,p,a,ap=curves(z['labels'],z['scores'])
    expected=next(x for x in (P if name=='ProtoCal' else D['baselines']) if x['seed']==42 and (name=='ProtoCal' or x['method']==name))
    assert abs(a-expected['auroc'])<1e-10,(name,a,expected['auroc'])
    assert abs(ap-expected['auprc'])<1e-10,(name,ap,expected['auprc'])
    axs[0].plot(f,t,color=color,ls=style,lw=1.7,label=f'{name} ({a:.3f})')
    axs[1].plot(r,p,color=color,ls=style,lw=1.5,label=f'{name} ({ap:.3f})')
prevalence=float(z['labels'].mean())
axs[0].plot([0,1],[0,1],color='#AAAAAA',lw=.8,ls='--')
axs[1].axhline(prevalence,color='#AAAAAA',lw=.9,ls='--',label=f'Prevalence ({prevalence:.3f})')
for ax in axs:ax.set_xlim(0,1);ax.set_ylim(0,1);ax.grid(alpha=.17,lw=.5);ax.legend(loc='lower right' if ax==axs[0] else 'upper right',frameon=False)
axs[0].set(xlabel='Known-class false-positive rate',ylabel='Novel-document recall',title='A  ROC curves (legend: AUROC)')
axs[1].set(xlabel='Novel-document recall',ylabel='Precision',title='B  Precision–recall (legend: AP)')
save(fig,'fig2_detection_curves',[f'results/scores_{name}_42.npz' for name in ['Softmax','Energy','ProtoCon']]+[f'results/scores_protocal_{s}.npz' for s in seeds])

# Figure 3. All three seeds displayed; error bars are sample SD, not CI.
fig,ax=plt.subplots(figsize=(6.8,2.85),layout='constrained')
values=[np.array([r['channel_auc']['R'] for r in P]),np.array([r['channel_auc']['G'] for r in P]),np.array([r['auroc'] for r in P])]
for i,(v,c) in enumerate(zip(values,COL)):
    ax.errorbar(i,v.mean(),yerr=v.std(ddof=1),color=c,fmt='o',ms=8,capsize=5,lw=1.6)
    ax.scatter(i+np.linspace(-.07,.07,len(v)),v,color=c,s=20,zorder=3,edgecolor='white',linewidth=.3)
    ax.text(i,v.max()+.045,f'{v.mean():.3f} ± {v.std(ddof=1):.3f}',ha='center',fontsize=8.5)
ax.axhline(.5,color='#888888',ls='--',lw=.8)
ax.set(xticks=[0,1,2],xticklabels=['Representation R','Trigger gap G','Dual-channel fusion'],ylabel='Detection AUROC',ylim=(0,1),xlim=(-.5,2.5))
ax.grid(axis='y',alpha=.17);ax.set_title('Mean and sample SD across three training seeds',loc='left')
save(fig,'fig3_channel_comparison',['results/results.json: protocal.channel_auc and auroc'])

# Figure 4. Detection and grouping must not be conflated.
fig,axs=plt.subplots(1,2,figsize=(7.2,3.1),layout='constrained')
x=np.arange(3);w=.23
for j,(name,vs,c) in enumerate([
 ('Detection F1',[r['f1'] for r in P],COL[0]),
 ('End-to-end type F1',[r['grouping']['e2e']['f1'] for r in P],COL[2]),
 ('Type-F1 upper bound',[r['grouping']['bound'] for r in P],'#BAC1C7')]):
    axs[0].bar(x+(j-1)*w,vs,w,color=c,label=name)
    for xx,v in zip(x+(j-1)*w,vs):axs[0].text(xx,v+.006,f'{v:.3f}',ha='center',fontsize=6.8,rotation=90,va='bottom')
axs[0].set(xticks=x,xticklabels=[str(s) for s in seeds],xlabel='Training seed',ylabel='F1',ylim=(0,.285),title='A  Detection limits end-to-end typing')
handles,labels=axs[0].get_legend_handles_labels()
fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,-.10),ncol=3,fontsize=7.4,frameon=False)
for j,(key,label,c) in enumerate([('purity','Purity',COL[1]),('ari','ARI',COL[0]),('nmi','NMI',COL[2])]):
    vs=np.array([r['grouping'][key] for r in P]);xx=x+(j-1)*w
    axs[1].scatter(xx,vs,s=30,color=c,label=label,zorder=3)
axs[1].set(xticks=x,xticklabels=[str(s) for s in seeds],xlabel='Training seed',ylabel='Clustering score',ylim=(-.055,1),title='B  High purity does not imply separation')
axs[1].legend(loc='center right',fontsize=7.4,frameon=False)
for ax in axs:ax.grid(axis='y',alpha=.17);ax.set_axisbelow(True)
save(fig,'fig4_detection_grouping',['results/results.json: protocal.grouping and f1'])

# Figure 5. Association with source is a retrospective confounding diagnostic.
q=D['source_diagnostic'];counts=q['counts'];domains=['cmnee','cmnie'];known=[counts[d]['n']-counts[d]['novel'] for d in domains];novel=[counts[d]['novel'] for d in domains]
fig,axs=plt.subplots(1,2,figsize=(7.2,2.9),layout='constrained')
axs[0].barh([1,0],known,color='#B7C8D8',label='Known document');axs[0].barh([1,0],novel,left=known,color=COL[1],label='Novel document')
for y,k,n in zip([1,0],known,novel):
    axs[0].text(k/2,y,str(k),ha='center',va='center',fontsize=8)
    axs[0].annotate(f'{n} novel',xy=(k+n/2,y),xytext=(k+n/2,y+.32),ha='center',fontsize=7.4,arrowprops={'arrowstyle':'-','color':'#555555','lw':.6})
axs[0].set(yticks=[1,0],yticklabels=['CMNEE','CMNIE'],xlabel='Test documents',ylim=(-.5,1.65),xlim=(0,3200),title='A  Novelty prevalence differs by corpus')
axs[0].legend(loc='upper center',bbox_to_anchor=(.5,-.20),ncol=2,fontsize=7.4,frameon=False)
v=np.array([r['auroc'] for r in P])
axs[1].errorbar(v.mean(),0,xerr=v.std(ddof=1),fmt='o',color=COL[0],capsize=4,ms=7)
axs[1].scatter(v,np.linspace(-.09,.09,3),color=COL[0],s=15)
axs[1].scatter([q['auroc']],[1],color=COL[1],marker='D',s=45)
axs[1].text(.98,-.35,f'{v.mean():.3f} ± {v.std(ddof=1):.3f}',ha='right',va='center',fontsize=8)
axs[1].text(.98,1,f'{q["auroc"]:.3f}',ha='right',va='center',fontsize=8)
axs[1].axvline(.5,color='#888888',ls='--',lw=.8)
axs[1].set(yticks=[0,1],yticklabels=['ProtoCal\nthree seeds','Source-only\nretrospective'],xlabel='AUROC',xlim=(0,1),ylim=(-.55,1.55),title='B  Pooled ranking is source-confounded')
axs[1].grid(axis='x',alpha=.17)
save(fig,'fig5_source_confound',['results/results.json: source_diagnostic and protocal.auroc'])

for item in manifest['figures']:
    item['png_sha256']=hashlib.sha256((OUT/(item['name']+'.png')).read_bytes()).hexdigest()
(OUT/'figure_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
print('Generated five figures; stored ROC and AP reproduced exactly.')
