"""Evaluation invariants exposing the defects in the supplied implementation."""
import unittest
import numpy as np
from corrected_protocol import multilabel_counts,threshold,ks_low,deduplicate_splits

class ProtocolTests(unittest.TestCase):
    def test_wrong_type_is_both_false_positive_and_false_negative(self):
        r=multilabel_counts([{'A'},{'B'}],[{'A'},{'A'}])
        self.assertEqual((r['tp'],r['fp'],r['fn']),(1,1,1))
        self.assertEqual(r['f1'],.5)

    def test_multiple_gold_labels_are_not_dropped(self):
        r=multilabel_counts([{'A'}],[{'A','B'}])
        self.assertEqual((r['tp'],r['fp'],r['fn']),(1,0,1))
        self.assertAlmostEqual(r['f1'],2/3)

    def test_unmatched_cluster_is_a_false_positive(self):
        r=multilabel_counts([{'__unmatched_0'}],[set()])
        self.assertEqual(r['fp'],1)

    def test_tied_calibration_does_not_flag_everything(self):
        tau,k=threshold(np.ones(20),.15)
        self.assertEqual(np.sum(np.ones(10)>tau),0)
        self.assertEqual(k,3)

    def test_small_calibration_set_defaults_to_no_flags(self):
        tau,k=threshold([.1,.2],.15)
        self.assertEqual(k,0)
        self.assertEqual(tau,float('inf'))

    def test_exact_ks_includes_left_limits(self):
        self.assertEqual(ks_low([.25,.25]),.75)
        self.assertEqual(ks_low([1.,1.]),.5)

    def test_split_overlap_is_removed(self):
        tr,va,te,removed=deduplicate_splits(
            [{'id':'a','text':'same'},{'id':'b','text':'same'}],
            [{'id':'c','text':'same'},{'id':'d','text':'different'}],
            [{'id':'e','text':'different'},{'id':'f','text':'test'}])
        self.assertEqual([x['id'] for x in tr],['a'])
        self.assertEqual([x['id'] for x in va],['d'])
        self.assertEqual([x['id'] for x in te],['f'])

if __name__=='__main__':unittest.main()
